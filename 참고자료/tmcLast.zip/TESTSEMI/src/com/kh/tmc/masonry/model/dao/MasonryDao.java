package com.kh.tmc.masonry.model.dao;

import static com.kh.tmc.common.JDBCTemplate.close;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.tmc.masonry.model.vo.Masonry;
import com.kh.tmc.masonry.model.vo.MasonryFavorite;

public class MasonryDao {

	private Properties prop;

	public MasonryDao() {
		prop = new Properties();
		String filePath = MasonryDao.class.getResource("/config/masonry-query.properties").getPath();

		try {
			prop.load(new FileReader(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public int masonryInsert(Connection con, Masonry ms) {

		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("masonryInsert");

		try {

			pstmt = con.prepareStatement(sql);

			pstmt.setString(1, ms.getTitle());
			pstmt.setString(2, ms.getContent());
			pstmt.setString(3, ms.getWriter());
			pstmt.setString(4, ms.getFileName());

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			close(pstmt);

		}

		return result;
	}

	public ArrayList<Masonry> MasonryList(Connection con) {

		ArrayList<Masonry> list = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;

		String sql = prop.getProperty("masonryList");

		try {

			list = new ArrayList<Masonry>();

			pstmt = con.prepareStatement(sql);

			rset = pstmt.executeQuery();

			while (rset.next()) {

				Masonry ms = new Masonry();

				ms.setmNo(rset.getInt("MNO"));
				ms.setTitle(rset.getString("TITLE"));
				ms.setContent(rset.getString("CONTENT"));
				ms.setWriter(rset.getString("WRITER"));
				ms.setFileName(rset.getString("FILENAME"));
				ms.setmCount(rset.getInt("MCOUNT"));

				list.add(ms);

			}

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {

			close(rset);
			close(pstmt);

		}

		return list;
	}

	public int deleteMasonry(Connection con, int mno) {

		int result = 0;
		System.out.println(mno);
		String sql = prop.getProperty("deleteMasonry");
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, mno);

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}

		return result;
	}

	public int MasonryFavoriteInsert(Connection con, String userId, int mNo) {

		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("MasonryFavoriteInsert");

		try {

			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, mNo);
			pstmt.setString(2, userId);

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			close(pstmt);

		}

		return result;
	}

	public int MasonryFavoriteDelete(Connection con, String userId, int mNo) {
		
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("MasonryFavoriteDelete");

		try {

			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, mNo);
			pstmt.setString(2, userId);

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			close(pstmt);

		}

		return result;
	}

	public ArrayList<MasonryFavorite> MasonryFavoriteList(Connection con) {
		
		ArrayList<MasonryFavorite> list = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;

		String sql = prop.getProperty("masonryFavorite");

		try {

			list = new ArrayList<MasonryFavorite>();

			pstmt = con.prepareStatement(sql);

			rset = pstmt.executeQuery();

			while (rset.next()) {

				MasonryFavorite ms = new MasonryFavorite();

				ms.setmNo(rset.getInt("mNo"));
				ms.setUserId(rset.getString("userId"));

				list.add(ms);

			}

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {

			close(rset);
			close(pstmt);

		}

		return list;
	}

}
