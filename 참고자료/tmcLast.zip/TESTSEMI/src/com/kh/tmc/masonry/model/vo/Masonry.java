package com.kh.tmc.masonry.model.vo;

import java.io.Serializable;

public class Masonry implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7189528449540053033L;

	private int mNo;
	private String title;
	private String content;
	private String writer;
	private String fileName;
	private String favorite;
	private int mCount;
	
	public Masonry() {
	}
	
	
	
	public Masonry(int mNo, String favorite) {
		this.mNo = mNo;
		this.favorite = favorite;
	}



	public Masonry(String title, String content, String writer, String fileName) {
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.fileName = fileName;
	}



	public Masonry(int mNo, String title, String content, String writer, String fileName) {
		this.mNo = mNo;
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.fileName = fileName;
	}
	
	public Masonry(int mNo, String title, String content, String writer, String fileName, int mCount) {
		super();
		this.mNo = mNo;
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.fileName = fileName;
		this.mCount = mCount;
	}

	
	
	public String getFavorite() {
		return favorite;
	}

	public void setFavorite(String favorite) {
		this.favorite = favorite;
	}



	public int getmCount() {
		return mCount;
	}

	public void setmCount(int mCount) {
		this.mCount = mCount;
	}

	public String getFileName() {
		return fileName;
	}



	public void setFileName(String fileName) {
		this.fileName = fileName;
	}



	public int getmNo() {
		return mNo;
	}

	public void setmNo(int mNo) {
		this.mNo = mNo;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}


	@Override
	public String toString() {
		return "Masonry [mNo=" + mNo + ", title=" + title + ", content=" + content + ", writer=" + writer
				+ ", fileName=" + fileName + ", mCount=" + mCount + "]";
	}



}
