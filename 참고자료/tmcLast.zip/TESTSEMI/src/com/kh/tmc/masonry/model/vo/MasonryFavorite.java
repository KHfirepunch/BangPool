package com.kh.tmc.masonry.model.vo;

import java.io.Serializable;

public class MasonryFavorite implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5328883482079215300L;
	
	private int mNo;
	private String userId;

	public MasonryFavorite() {
	}

	
	public MasonryFavorite(int mNo, String userId) {
		this.mNo = mNo;
		this.userId = userId;
	}
	

	public int getmNo() {
		return mNo;
	}


	public void setmNo(int mNo) {
		this.mNo = mNo;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	@Override
	public String toString() {
		return "MasonryFavorite [mNo=" + mNo + ", userId=" + userId + "]";
	}

	
	
	
	

}
