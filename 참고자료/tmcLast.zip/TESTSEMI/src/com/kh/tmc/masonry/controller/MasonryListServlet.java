package com.kh.tmc.masonry.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.masonry.model.service.MasonryService;
import com.kh.tmc.masonry.model.vo.Masonry;
import com.kh.tmc.masonry.model.vo.MasonryFavorite;
import com.kh.tmc.masonryComment.model.service.MasonryCommentService;
import com.kh.tmc.masonryComment.model.vo.MasonryComment;

/**
 * Servlet implementation class MasonryListServlet
 */
@WebServlet("/masonryList.do")
public class MasonryListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MasonryListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ArrayList<Masonry> list = null;
		ArrayList<MasonryFavorite> favorite = null;
		ArrayList<MasonryComment> clist = null;
		
		MasonryCommentService mcs = new MasonryCommentService();
		MasonryService ms = new MasonryService();
		
		list = ms.MasonryList();
		clist = mcs.masonryCommentList();
		favorite = ms.MasonryFavoriteList();

		String page = "";

		if (list != null) {
			
			page = "views/masonry/masonryBoard.jsp";
			request.setAttribute("list", list);
			request.setAttribute("favorite", favorite);
			request.setAttribute("clist", clist);
			
		} else {
			page = "views/masonry/masonryBoard.jsp";
		}
		request.getRequestDispatcher(page).forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
