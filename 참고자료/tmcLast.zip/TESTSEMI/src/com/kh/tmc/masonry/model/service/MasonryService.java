package com.kh.tmc.masonry.model.service;

import static com.kh.tmc.common.JDBCTemplate.close;
import static com.kh.tmc.common.JDBCTemplate.commit;
import static com.kh.tmc.common.JDBCTemplate.getConnection;
import static com.kh.tmc.common.JDBCTemplate.rollback;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.tmc.masonry.model.dao.MasonryDao;
import com.kh.tmc.masonry.model.vo.Masonry;
import com.kh.tmc.masonry.model.vo.MasonryFavorite;

public class MasonryService {

	private MasonryDao md = new MasonryDao();

	public int masonryInsert(Masonry ms) {

		Connection con = getConnection();

		int result = md.masonryInsert(con, ms);

		if (result > 0) {
			commit(con);
		} else {
			rollback(con);
		}

		close(con);

		return result;
	}

	public ArrayList<Masonry> MasonryList() {

		Connection con = getConnection();

		ArrayList<Masonry> list = md.MasonryList(con);

		close(con);

		return list;
	}

	public int deleteMasonry(int mno) {

		Connection con = getConnection();

		int result = md.deleteMasonry(con, mno);

		if (result >= 1)
			commit(con);
		else
			rollback(con);

		close(con);

		return result;
	}

	public int MasonryFavoriteInsert(String userId, int mNo) {

		Connection con = getConnection();

		int result = md.MasonryFavoriteInsert(con, userId,mNo);

		if (result > 0) {
			commit(con);
		} else {
			rollback(con);
		}

		close(con);

		return result;
	}

	public int MasonryFavoriteDelete(String userId,int mNo) {

		Connection con = getConnection();

		int result = md.MasonryFavoriteDelete(con, userId,mNo);

		if (result > 0) {
			commit(con);
		} else {
			rollback(con);
		}

		close(con);

		return result;
	}

	public ArrayList<MasonryFavorite> MasonryFavoriteList() {
		
		Connection con = getConnection();

		ArrayList<MasonryFavorite> list = md.MasonryFavoriteList(con);

		close(con);

		return list;
		
	}

}
