package com.kh.tmc.masonry.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.masonry.model.service.MasonryService;
import com.kh.tmc.masonry.model.vo.Masonry;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

/**
 * Servlet implementation class MarsonryInsertServlet
 */
@WebServlet("/masonryInsert.do")
public class MasonryInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MasonryInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Masonry ms = new Masonry();
		
		int maxSize = 1024 * 1024 *10;
		
		String root = request.getServletContext().getRealPath("/");
		String savePath = root + "resourse/masonryImg";
		
		MultipartRequest mrequest = new MultipartRequest(request, savePath,maxSize,"UTF-8",new DefaultFileRenamePolicy());
		
		String title = mrequest.getParameter("title");
		String content = mrequest.getParameter("content");
		String writer = mrequest.getParameter("userId");		
		String fileName = mrequest.getFilesystemName("file");
		
		ms = new Masonry(title, content, writer, fileName);
		
		int result = new MasonryService().masonryInsert(ms);
		
		if(result>0) {
			response.sendRedirect("/tmc/masonryList.do");
		}
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
