package com.kh.tmc.adoptWantComment.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.tmc.adoptWant.model.vo.AdoptWant;
import com.kh.tmc.adoptWantComment.model.dao.AdoptWantCommentDao;
import com.kh.tmc.adoptWantComment.model.vo.AdoptWantComment;
import static com.kh.tmc.common.JDBCTemplate.*;

public class AdoptWantCommentService {

	private AdoptWantCommentDao awcDao = new AdoptWantCommentDao();
	
	public int deleteWantComment(AdoptWantComment awc) {
		Connection con = getConnection();
		
		int result = awcDao.deleteComment(con,awc);
		
		if(result>0) commit(con);
		else rollback(con);
		
		return result;
	}

	public int insertAdoptWantCommentInsert(AdoptWantComment awc) {
		
		Connection con = getConnection();
		
		int result = awcDao.insertAdoptWantCommentInsert(con,awc);
		
		if(result>0) commit(con);
		else rollback(con);
		
		close(con);
		
		return result;
		
	}

	public ArrayList<AdoptWantComment> selectAdoptWantCommentList(int wiBno) {
		Connection con = getConnection();
		
		ArrayList<AdoptWantComment> wisCommentList = awcDao.selectAdoptWantCommentList(con, wiBno);
		
		close(con);
		
		return wisCommentList;
	}

	public int updateAdoptWantComment(AdoptWantComment awc) {
		Connection con = getConnection();
		
		int result = awcDao.updateAdoptWantComment(con,awc);
		
		if(result>0) commit(con);
		else rollback(con);
		close(con);
		
		return result;
	}

}
