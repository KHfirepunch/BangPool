package com.kh.tmc.adoptWantComment.model.dao;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.tmc.adoptWant.model.vo.AdoptWant;
import com.kh.tmc.adoptWantComment.model.vo.AdoptWantComment;
import static com.kh.tmc.common.JDBCTemplate.*;

public class AdoptWantCommentDao {
	Properties prop = new Properties();
	
	public AdoptWantCommentDao() {
		
		String filePath = AdoptWantCommentDao.class.getResource("/config/adoptWantComment-query.properties").getPath();
	
		try{
			prop.load(new FileReader(filePath)); 
		}catch(IOException e){
			e.printStackTrace();
		}
	}

	public int deleteComment(Connection con, AdoptWantComment awc) {
		int result= 0;
		
		PreparedStatement pstmt = null;
		
		String sql = prop.getProperty("deleteAdoptWantComment");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, awc.getWiBno());
			pstmt.setInt(2, awc.getWicNo());
			
			
			result = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		return result;
	}

	public int insertAdoptWantCommentInsert(Connection con, AdoptWantComment awc) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("insertAdoptWantComment");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, awc.getWiBno());
			pstmt.setString(2, awc.getWicContent());
			pstmt.setString(3, awc.getWicWriter());
			
			if(awc.getWicRefno()>0) {
				pstmt.setInt(4, awc.getWicRefno());
			}else {
				pstmt.setInt(4, java.sql.Types.NULL );
			}
			
			pstmt.setInt(5, awc.getWicLevel());
			
			result = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			close(pstmt);
		}
		
		
		return result;
	}

	public ArrayList<AdoptWantComment> selectAdoptWantCommentList(Connection con, int wiBno) {
		ArrayList<AdoptWantComment> wisCommentList= null;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("selectAdoptWantCommentList");
		ResultSet rset = null;
		
		try {
			wisCommentList = new ArrayList<AdoptWantComment>();
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, wiBno);
			
			rset = pstmt.executeQuery();
			
			while(rset.next()) {
				AdoptWantComment awc = new AdoptWantComment();
				
				awc.setWicNo(rset.getInt("WICNO"));
				awc.setWiBno(wiBno);
				awc.setWicContent(rset.getString("WICCONTENT"));
				awc.setWicWriter(rset.getString("WICWRITER"));
				awc.setWicdate(rset.getDate("WICDATE"));
				awc.setWicRefno(rset.getInt("WICREFNO"));
				awc.setWicLevel(rset.getInt("WICLEVEL"));
				
				wisCommentList.add(awc);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		return wisCommentList;
	}

	public int updateAdoptWantComment(Connection con, AdoptWantComment awc) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("updateAdoptWantComment");
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, awc.getWicContent());
			pstmt.setInt(2, awc.getWiBno());
			pstmt.setInt(3, awc.getWicNo());
			
			result = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}

}
