package com.kh.tmc.adoptWantComment.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.adoptWantComment.model.service.AdoptWantCommentService;
import com.kh.tmc.adoptWantComment.model.vo.AdoptWantComment;

/**
 * Servlet implementation class AdoptCommentIsenrt
 */
@WebServlet("/iAdoptWCo.ado")
public class AdoptWantCommentInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdoptWantCommentInsert() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String wicWriter = request.getParameter("wicWriter");
		int wiBno = Integer.parseInt(request.getParameter("wiBno"));
		int wicRefno = Integer.parseInt(request.getParameter("wicRefno"));
		int wicLevel = Integer.parseInt(request.getParameter("wicLevel"));
		String wicContent = request.getParameter("wicContent");
		
		AdoptWantComment awc = new AdoptWantComment(wiBno,wicContent,wicWriter,wicRefno,wicLevel);
		
		
		
		int result = new AdoptWantCommentService().insertAdoptWantCommentInsert(awc);
		
		if(result > 0) {
			response.sendRedirect("soAdoptW.ado?wiBno="+wiBno);
		}else {
			request.setAttribute("msg", "댓글 작성 실패 !");
			request.getRequestDispatcher("views/common/errorPage.jsp").forward(request, response);
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
