package com.kh.tmc.adoptWantComment.model.vo;

import java.sql.Date;

public class AdoptWantComment {
	private int wicNo;
	private int wiBno;
	private String wicContent;
	private String wicWriter;
	private Date wicdate;
	private int wicRefno;
	private int wicLevel;
	
	public AdoptWantComment() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	public int getWicNo() {
		return wicNo;
	}



	public void setWicNo(int wicNo) {
		this.wicNo = wicNo;
	}



	public int getWiBno() {
		return wiBno;
	}



	public void setWiBno(int wiBno) {
		this.wiBno = wiBno;
	}



	public String getWicContent() {
		return wicContent;
	}



	public void setWicContent(String wicContent) {
		this.wicContent = wicContent;
	}



	public String getWicWriter() {
		return wicWriter;
	}



	public void setWicWriter(String wicWriter) {
		this.wicWriter = wicWriter;
	}



	public Date getWicdate() {
		return wicdate;
	}



	public void setWicdate(Date wicdate) {
		this.wicdate = wicdate;
	}



	public int getWicRefno() {
		return wicRefno;
	}



	public void setWicRefno(int wicRefno) {
		this.wicRefno = wicRefno;
	}



	public int getWicLevel() {
		return wicLevel;
	}



	public void setWicLevel(int wicLevel) {
		this.wicLevel = wicLevel;
	}
	
	


	public AdoptWantComment(int wiBno, String wicContent, String wicWriter, int wicRefno, int wicLevel) {
		super();
		this.wiBno = wiBno;
		this.wicContent = wicContent;
		this.wicWriter = wicWriter;
		this.wicRefno = wicRefno;
		this.wicLevel = wicLevel;
	}



	public AdoptWantComment(int wicNo, int wiBno, String wicContent, String wicWriter, Date wicdate, int wicRefno,
			int wicLevel) {
		super();
		this.wicNo = wicNo;
		this.wiBno = wiBno;
		this.wicContent = wicContent;
		this.wicWriter = wicWriter;
		this.wicdate = wicdate;
		this.wicRefno = wicRefno;
		this.wicLevel = wicLevel;
	}



	@Override
	public String toString() {
		return "AdoptComment [wicNo=" + wicNo + ", wiBno=" + wiBno + ", wicContent=" + wicContent + ", wicWriter="
				+ wicWriter + ", wicdate=" + wicdate + ", wicRefno=" + wicRefno + ", wicLevel=" + wicLevel + "]";
	}
}
