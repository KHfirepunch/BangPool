package com.kh.tmc.donation.model.dao;

import java.sql.Statement;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.tmc.donation.model.vo.Donation;

import static com.kh.tmc.common.JDBCTemplate.*;
public class DonationDao {
	
	private Properties prop = new Properties();
	
	public DonationDao() {
		String filePath = DonationDao.class.getResource("/config/donation-query.properties").getPath();
		try {
			prop.load(new FileReader(filePath));
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public int insertDonation(Connection con, Donation d) {
		
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("insertdona");
		
		System.out.println("잘갔뜨");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			
			pstmt.setString(1, d.getSpid());
			pstmt.setString(2, d.getSpname());
			pstmt.setString(3, d.getSpphone());
			pstmt.setString(4, d.getSpaddress());
			pstmt.setString(5, d.getSmsCheck());
			pstmt.setInt(6, d.getMoney());
			
			
			
			
			
			result = pstmt.executeUpdate();
			
			System.out.println("dDao의 결과 : " + result);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}

	public ArrayList<Donation> selectList(Connection con, int currentPage, int limit) {
		ArrayList<Donation> list = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String sql = prop.getProperty("selectList");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			
			int startRow = (currentPage - 1) * limit + 1; // 1, 11, 21
			
			int endRow = startRow + limit - 1; // 10, 20, 30
			pstmt.setInt(1, endRow);
			pstmt.setInt(2, startRow);
			
			rset = pstmt.executeQuery();
			
			list = new ArrayList<Donation>();
			
			while(rset.next()){
				Donation d = new Donation();
				
				d.setDno(rset.getInt("dno"));
				d.setSpid(rset.getString("spid"));
				d.setSpname(rset.getString("spname"));
				d.setMoney(rset.getInt("money"));
				d.setSydate(rset.getDate("sydate"));
				
				list.add(d);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		return list;
	}
	
	public int getListCount(Connection con) {
		
		// 총 게시글 수
		int listCount = 0;
		Statement stmt = null;
		ResultSet rset = null;
		
		String sql = prop.getProperty("listCount");
		
		try {
			stmt = con.createStatement();
			
			rset = stmt.executeQuery(sql);
			
			if(rset.next()) {
				listCount = rset.getInt(1);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(stmt);
		}
		
		return listCount;
	}

}
