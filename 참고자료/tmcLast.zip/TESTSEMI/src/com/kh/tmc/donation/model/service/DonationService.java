package com.kh.tmc.donation.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.tmc.donation.model.dao.DonationDao;
import com.kh.tmc.donation.model.vo.Donation;
import static com.kh.tmc.common.JDBCTemplate.*;

public class DonationService {
	
	private DonationDao dDao = new DonationDao();
	
	
	public int getListCount() {
		Connection con = getConnection();
		
		int listCount = dDao.getListCount(con);
		
		close(con);
		return listCount;
	}
	
	public int insertDonation(Donation d) {
		Connection con = getConnection();
		
		int result = dDao.insertDonation(con, d);
		
		System.out.println("ds의 result : " + result);
		
		if(result >0)commit(con);
		else rollback(con);
		
		close(con);
		
		return result;
		
		
	}
	
	public ArrayList<Donation> selectList(int currentPage, int limit){
		Connection con = getConnection();
		
		ArrayList<Donation> list = dDao.selectList(con, currentPage, limit);
		
		close(con);
		
		return list;
	}
	
	



}
