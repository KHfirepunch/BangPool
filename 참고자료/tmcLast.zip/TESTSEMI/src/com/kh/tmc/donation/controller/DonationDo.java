package com.kh.tmc.donation.controller;

import java.io.IOException;
import java.sql.Date;
import java.util.GregorianCalendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.donation.model.service.DonationService;
import com.kh.tmc.donation.model.vo.Donation;

/**
 * Servlet implementation class DonationDo
 */
@WebServlet("/donation.do")
public class DonationDo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DonationDo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String spid = request.getParameter("spid");
		String spname = request.getParameter("spname");
		String spphone = request.getParameter("spphone");
		String spaddress = request.getParameter("addr")
			       + request.getParameter("addrdetail")
			       + request.getParameter("addrDtl");
		String smsCheck = request.getParameter("smsYn");
		int money = Integer.parseInt(request.getParameter("money"));
		
		Donation d = new Donation();
		
		d.setSpid(spid);
		d.setSpname(spname);
		d.setSpphone(spphone);
		d.setSpaddress(spaddress);
		d.setSmsCheck(smsCheck);
		d.setMoney(money);
		
		System.out.println("후원자 정보 확인 : " + d);
		
		DonationService ds = new DonationService();
		
		int result = ds.insertDonation(d);
		
		if(result > 0) {
			System.out.println("후원 성공");
			request.getRequestDispatcher("/views/donation/donapay.jsp").forward(request, response);
		}else {
			
			request.setAttribute("msg", " 실패!");
			request.getRequestDispatcher("views/common/errorPage.jsp")
			.forward(request, response);
		}
		
		}
		
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
