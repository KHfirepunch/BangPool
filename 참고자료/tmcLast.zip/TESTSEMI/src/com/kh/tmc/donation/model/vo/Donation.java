package com.kh.tmc.donation.model.vo;

import java.io.Serializable;
import java.sql.Date;

public class Donation implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1492475422216228580L;
	
	private int dno;
	private String spid;
	private String spname;
	private String spphone;
	private String spaddress;
	private String smsCheck;
	private int money;
	private Date sydate;
	
	
	public Donation() {}

	// 후원자 정보 입력 생성자
	public Donation(String spid, String spname, String spphone, String spaddress, String smsCheck, int money
			) {
		super();
		this.spid = spid;
		this.spname = spname;
		this.spphone = spphone;
		this.spaddress = spaddress;
		this.smsCheck = smsCheck;
		this.money = money;
		
	}

	// 후원자 정보 전체 데이터를 가져오기 위한 생성자
	public Donation(int dno, String spid, String spname, String spphone, String spaddress, String smsCheck,
			 int money, Date sydate) {
		super();
		this.dno = dno;
		this.spid = spid;
		this.spname = spname;
		this.spphone = spphone;
		this.spaddress = spaddress;
		this.smsCheck = smsCheck;
		this.money = money;
		this.sydate = sydate;
	}
	

	public int getDno() {
		return dno;
	}

	public void setDno(int dno) {
		this.dno = dno;
	}

	public String getSpid() {
		return spid;
	}


	public void setSpid(String spid) {
		this.spid = spid;
	}


	public String getSpname() {
		return spname;
	}


	public void setSpname(String spname) {
		this.spname = spname;
	}


	public String getSpphone() {
		return spphone;
	}


	public void setSpphone(String spphone) {
		this.spphone = spphone;
	}


	public String getSpaddress() {
		return spaddress;
	}


	public void setSpaddress(String spaddress) {
		this.spaddress = spaddress;
	}


	public String getSmsCheck() {
		return smsCheck;
	}


	public void setSmsCheck(String smsCheck) {
		this.smsCheck = smsCheck;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public Date getSydate() {
		return sydate;
	}


	public void setSydate(Date sydate) {
		this.sydate = sydate;
	}

	@Override
	public String toString() {
		return "Donation [dno=" + dno + ", spid=" + spid + ", spname=" + spname + ", spphone=" + spphone
				+ ", spaddress=" + spaddress + ", smsCheck=" + smsCheck + ", money=" + money + ", sydate=" + sydate
				+ "]";
	}



	



	

}
