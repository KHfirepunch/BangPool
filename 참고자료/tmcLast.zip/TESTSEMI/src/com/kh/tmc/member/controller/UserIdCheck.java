package com.kh.tmc.member.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.member.model.service.MemberService;
import com.kh.tmc.member.model.vo.Member;

/**
 * Servlet implementation class UserIdCheck
 */
@WebServlet("/checkId.do")
public class UserIdCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserIdCheck() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String check ="";
		String userId = request.getParameter("userId");
		
		Member m = new Member();
		m.setUserId(userId);
		
		int count = new MemberService().CheckId(m);
		
		if(count>0) {
			check = "no";
		}else {
			check="ok";
		}	
		
		response.getWriter().print(check);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
