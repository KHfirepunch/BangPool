package com.kh.tmc.adoptMaching.model.dao;

import static com.kh.tmc.common.JDBCTemplate.close;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.tmc.adopt.model.dao.AdoptDao;
import com.kh.tmc.adoptMaching.model.vo.DogTable;

public class MachingDao {

	Properties prop = new Properties();
	public MachingDao() {
		try {
			String filePath = AdoptDao.class
					.getResource("/config/dogMaching-query.properties")
					.getPath();
			prop.load(new FileInputStream(filePath));
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<DogTable> selectDogList(Connection con) {
		ArrayList<DogTable> dlist = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String sql = prop.getProperty("selectDogList");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			rset = pstmt.executeQuery();
			dlist = new ArrayList<DogTable>();
			
			while(rset.next()) {
				DogTable dt = new DogTable();
				
				dt.setDogkind(rset.getString("DOGKIND"));
				dt.setDogColor(rset.getString("DOGCOLOR"));
				dt.setDogWalk(rset.getDouble("DOGWALK"));
				dt.setDogType(rset.getString("DOGTYPE"));
				
				dlist.add(dt);
			}
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		return dlist;
	}

}
