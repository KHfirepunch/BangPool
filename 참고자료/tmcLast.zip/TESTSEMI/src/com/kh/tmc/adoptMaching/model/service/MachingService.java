package com.kh.tmc.adoptMaching.model.service;

import static com.kh.tmc.common.JDBCTemplate.close;
import static com.kh.tmc.common.JDBCTemplate.getConnection;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.tmc.adoptMaching.model.dao.MachingDao;
import com.kh.tmc.adoptMaching.model.vo.DogTable;

public class MachingService {
	MachingDao mDao = new MachingDao();
	
	public ArrayList<DogTable> selectDogList() {
		// TODO Auto-generated method stub
		Connection con = getConnection();
		ArrayList<DogTable> dlist = mDao.selectDogList(con);
				
		close(con);
		
		return dlist;
	}

}
