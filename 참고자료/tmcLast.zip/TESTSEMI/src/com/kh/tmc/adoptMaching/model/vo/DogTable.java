package com.kh.tmc.adoptMaching.model.vo;

import java.io.Serializable;

public class DogTable implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 259920727278091254L;
	private String dogkind;
	private String dogColor;
	private Double dogWalk;
	private String dogType;
	public DogTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getDogkind() {
		return dogkind;
	}
	public void setDogkind(String dogkind) {
		this.dogkind = dogkind;
	}
	public String getDogColor() {
		return dogColor;
	}
	public void setDogColor(String dogColor) {
		this.dogColor = dogColor;
	}
	public Double getDogWalk() {
		return dogWalk;
	}
	public void setDogWalk(Double dogWalk) {
		this.dogWalk = dogWalk;
	}
	public String getDogType() {
		return dogType;
	}
	public void setDogType(String dogType) {
		this.dogType = dogType;
	}
	public DogTable(String dogkind, String dogColor, Double dogWalk, String dogType) {
		super();
		this.dogkind = dogkind;
		this.dogColor = dogColor;
		this.dogWalk = dogWalk;
		this.dogType = dogType;
	}
	@Override
	public String toString() {
		return "DogTable [dogkind=" + dogkind +  ", dogColor=" + dogColor + ", dogWalk="
				+ dogWalk + ", dogType=" + dogType + "]";
	}
	
	
}

	



