package com.kh.tmc.notice.model.service;

import static com.kh.tmc.common.JDBCTemplate.*;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.tmc.notice.model.dao.NoticeDao;
import com.kh.tmc.notice.model.vo.Notice;

public class NoticeService {
	
	private NoticeDao nDao = new NoticeDao();
	
	public int getListCount() {
		
		Connection con = getConnection();
		
		int listCount = nDao.getListCount(con);
		
		close(con);
		
		return listCount;
	}
	
	/*public ArrayList<Notice> selectList() {
		Connection con = getConnection();
		
		ArrayList<Notice> list = nDao.selectList(con);
		
		close(con);
		
		return list;
		
	}*/
	
	public ArrayList<Notice> selectList(int currentPage, int limit) {
		
		Connection con = getConnection();
		
		ArrayList<Notice> list = nDao.selectList(con,currentPage,limit);
		
		close(con);
		
		return list;
	}

	public int insertNotice(Notice n) {
		
		Connection con = getConnection();
		
		int result = nDao.insertNotice(con,n);
		
		/*
		 * 0   : 실행한 행의 개수 없음
		 * 1이상 : n개의 행 실행
		 * -1  : 실행 중 에러발생 
		 * */
		if(result >= 1) commit(con);
		else rollback(con);
		
		close(con);
		
		return result;
	}

	public Notice selectOne(int nno) {
		
		Connection con = getConnection();
		// 상세내용
		Notice n = nDao.selectOne(con,nno);
		
		// 게시글 상세보기를 통해 1회 조회할 때
		// 2가지 기능이 실행된다.
		// 1. nno에 해당하는 게시글 내용을 가져오기(SELECT)
		// 2. 게시글 내용이 성공적으로 호출이되면 조회수가 1증가해야한다.(UPDATE)
		
		if(n!=null) {
			int result = nDao.updateReadCount(con,nno);
			
			if(result>0) commit(con);
			else rollback(con);
		}
		
		close(con);
		
		return n;
	}

	public int updateNotice(Notice n) {
		
		Connection con = getConnection();
		
		int result = nDao.updateNotice(con,n);
		
		if(result >0) commit(con);
		else rollback(con);
		
		close(con);
		
		return result;
	}

	public Notice updateView(int nno) {
		
		Connection con = getConnection();
		
		Notice n = nDao.selectOne(con, nno);
		
		close(con);
		
		return n;
	}
	
	public int deleteNotice(int nno) {
		
		Connection con = getConnection();
		
		int result = nDao.deleteNotice(con,nno);
		
		if(result >0) commit(con);
		else rollback(con);
		
		close(con);
		
		return result;
	}

	public ArrayList<Notice> searchNotice(String category, String keyword,int currentPage,int limit) {
		
		Connection con = getConnection();
		
		ArrayList<Notice> list = null;
		
		list = (category.length()>0)?
				nDao.searchNotice(con,category,keyword,currentPage,limit):nDao.selectList(con,currentPage,limit);
		
		close(con);
				
		return list;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
