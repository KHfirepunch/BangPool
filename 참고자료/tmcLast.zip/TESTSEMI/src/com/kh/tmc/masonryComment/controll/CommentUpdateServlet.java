package com.kh.tmc.masonryComment.controll;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.masonryComment.model.service.MasonryCommentService;
import com.kh.tmc.masonryComment.model.vo.MasonryComment;

/**
 * Servlet implementation class CommentUpdateServlet
 */
@WebServlet("/updateComment.bo")
public class CommentUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CommentUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int cno = Integer.parseInt(request.getParameter("cno"));
		int mno = Integer.parseInt(request.getParameter("mno"));
		String content = request.getParameter("content");
		
		MasonryComment mco = new MasonryComment(cno,mno,content);
		
		int result = new MasonryCommentService().updateComment(mco);
		
		
		if(result>0) {
			response.sendRedirect("selectOne.bo?mno="+mno);
		}else {
			request.setAttribute("msg", "댓글 수정 실패!");
			request.getRequestDispatcher("views/common/errorPage.jsp");
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
