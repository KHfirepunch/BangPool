package com.kh.tmc.masonryComment.model.service;

import static com.kh.tmc.common.JDBCTemplate.*;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.tmc.masonryComment.model.dao.MasonryCommentDao;
import com.kh.tmc.masonryComment.model.vo.MasonryComment;

public class MasonryCommentService {
	
	private MasonryCommentDao mcDao = new MasonryCommentDao();

	public int insertComment(MasonryComment mco) {
		
		Connection con = getConnection();
		
		int result = mcDao.insertComment(con,mco);
		
		if(result>0) commit(con);
		else rollback(con);
		
		return result;
	}

	public ArrayList<MasonryComment> selectList(int mno) {
		
		Connection con = getConnection();
		
		ArrayList<MasonryComment> clist
			= mcDao.selectList(con,mno);
		
		close(con);
		
		return clist;
	}

	public int updateComment(MasonryComment mco) {
		
		Connection con = getConnection();
		
		int result = mcDao.updateComment(con,mco);
		
		if(result>0) commit(con);
		else rollback(con);
		
		return result;
	}

	public int deleteComment(MasonryComment mco) {
		
		Connection con = getConnection();
		
		int result = mcDao.deleteComment(con,mco);
		
		if(result>0) commit(con);
		else rollback(con);
		
		return result;
	}

	public ArrayList<MasonryComment> masonryCommentList(){
		
		Connection con = getConnection();
		
		ArrayList<MasonryComment> clist = mcDao.masonryCommentList(con);
		
		close(con);
		
		return clist;
	}
	
	
}
