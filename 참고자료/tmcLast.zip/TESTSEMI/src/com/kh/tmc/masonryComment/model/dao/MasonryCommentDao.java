package com.kh.tmc.masonryComment.model.dao;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import static com.kh.tmc.common.JDBCTemplate.*;

import com.kh.tmc.masonryComment.model.vo.MasonryComment;

public class MasonryCommentDao {

	private Properties prop = new Properties();
	
	public MasonryCommentDao() {
		String filePath = MasonryCommentDao.class.getResource("/config/comment-query.properties").getPath();
		
		try {
			prop.load(new FileReader(filePath));
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public int insertComment(Connection con, MasonryComment mco) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("insertComment");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, mco.getMno());
			pstmt.setString(2, mco.getCcontent());
			pstmt.setString(3, mco.getCwriter());
			
			if(mco.getRefcno()>0) {
				pstmt.setInt(4, mco.getRefcno());
			}else {
				pstmt.setNull(4, java.sql.Types.NULL);
			}
			
			pstmt.setInt(5, mco.getClevel());
			
			result = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}

	public ArrayList<MasonryComment> selectList(Connection con, int mno) {
		
		ArrayList<MasonryComment> clist = null;
		
		PreparedStatement pstmt = null;
		
		ResultSet rset = null;
		
		String sql = prop.getProperty("selectList");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, mno);
			
			rset = pstmt.executeQuery();
			
			clist = new ArrayList<MasonryComment>();
			
			while(rset.next()) {
				
				MasonryComment mco = new MasonryComment();
				
				mco.setCno(rset.getInt("CNO"));
				mco.setMno(mno);
				mco.setCcontent(rset.getString("CCONTENT"));
				mco.setCwriter(rset.getString("USERNAME"));
				mco.setCwriterId(rset.getString("CWRITER"));
				mco.setCdate(rset.getDate("CDATE"));
				mco.setRefcno(rset.getInt("REFCNO"));
				mco.setClevel(rset.getInt("CLEVEL"));
				
				clist.add(mco);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		
		return clist;
	}

	public int updateComment(Connection con, MasonryComment mco) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("updateComment");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, mco.getCcontent());
			pstmt.setInt(2, mco.getCno());
			pstmt.setInt(3, mco.getMno());
			
			
			result = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}

	public int deleteComment(Connection con, MasonryComment mco) {
		
		int result = 0;
		
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("deleteComment");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, mco.getCno());
			pstmt.setInt(2, mco.getMno());
			
			
			result = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}

	public ArrayList<MasonryComment> masonryCommentList(Connection con) {
		
		ArrayList<MasonryComment> clist = null;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("selectMasonry");
		ResultSet rset = null;
		
		try {
			pstmt = con.prepareStatement(sql);
			
			rset = pstmt.executeQuery();
			
			clist = new ArrayList<MasonryComment>();
			
			while(rset.next()) {
				
				MasonryComment mc = new MasonryComment();
				
				mc.setCno(rset.getInt("CNO"));
				mc.setMno(rset.getInt("MNO"));
				mc.setCcontent(rset.getString("CCONTENT"));
				mc.setCwriter(rset.getString("CWRITER"));
				mc.setCdate(rset.getDate("CDATE"));
				mc.setRefcno(rset.getInt("REFCNO"));
				mc.setClevel(rset.getInt("CLEVEL"));
				
				clist.add(mc);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		
		return clist;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
