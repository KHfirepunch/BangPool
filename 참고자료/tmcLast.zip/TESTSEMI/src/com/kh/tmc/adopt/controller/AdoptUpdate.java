package com.kh.tmc.adopt.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import com.kh.tmc.adopt.model.service.AdoptService;
import com.kh.tmc.adopt.model.vo.Adopt;
import com.kh.tmc.adopt.model.vo.Attachment;
import com.kh.tmc.common.MyRenamePolicy;
import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class UpdateAdopt
 */
@WebServlet("/uAdopt.ado")
public class AdoptUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdoptUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AdoptService ts = new AdoptService();
		
		int maxSize = 1024*1024*10;
		
		if(!ServletFileUpload.isMultipartContent(request)) {
			// 에러 페이지 전송
			request.setAttribute("msg", "멀티파트 폼으로 전송해야 합니다.");
			request.getRequestDispatcher("views/common/errorPage.jsp")
			.forward(request, response);
		}
	
		String root = request.getServletContext().getRealPath("/resourse");
		
		String savePath = root+"/adoptUploadFiles/";
		
		MultipartRequest mrequest = new MultipartRequest(
												  request
												, savePath
												, maxSize
												,"UTF-8"
												,new MyRenamePolicy());
		
		int iNo = Integer.parseInt(mrequest.getParameter("iNo"));
		
		// 원본 파일의 경로 확인하기
		HashMap<String,Object> hmap = ts.selectAdoptMap(iNo);
	
		ArrayList<String> saveFiles = new ArrayList<String>();
		ArrayList<String> originFiles = new ArrayList<String>();
		
		// 전달된 파일 정보 가져오기
		Enumeration<String> files = mrequest.getFileNames();
		while(files.hasMoreElements()) {
			String name = files.nextElement();
			
			saveFiles.add(mrequest.getFilesystemName(name));
			originFiles.add(mrequest.getFilesystemName(name));
		}
	
		Adopt adopt = (Adopt)hmap.get("adopt");
		
		adopt.setiTitle(mrequest.getParameter("adoptTitle"));
		adopt.setiWriter(mrequest.getParameter("adoptWriter"));
		adopt.setiName(mrequest.getParameter("iName"));
		adopt.setiAnimalBreed(mrequest.getParameter("iAnimalBreed"));
		adopt.setiAge(Integer.parseInt(mrequest.getParameter("iAge")));
		adopt.setiArea(mrequest.getParameter("iArea"));
		adopt.setiWeith(Double.parseDouble(mrequest.getParameter("iWeith")));
		adopt.setShelterName(mrequest.getParameter("shelterName"));
		adopt.setiHairColor(mrequest.getParameter("iHairColor"));
		adopt.setiGender(mrequest.getParameter("iGender"));
		adopt.setiVaccination(mrequest.getParameter("iVaccination"));
		adopt.setiDefecationTraining(mrequest.getParameter("iDefecationTraining"));
		adopt.setiContent(mrequest.getParameter("iContent"));
		adopt.setiState("Y");
		
		ArrayList<Attachment> list
		= (ArrayList<Attachment>)hmap.get("attachment");
		
		for(int i= originFiles.size()-1; i>=0;i--) {
			int j= originFiles.size() - i - 1;
			
			if(originFiles.get(i) != null) {
				new File(savePath + list.get(j).getChangename()).delete();
			
			list.get(j).setFilePath(savePath);
			list.get(j).setChangename(saveFiles.get(i));
			list.get(j).setOriginname(originFiles.get(i));
			}
		}
		
		int result = ts.updateAdopt(adopt,list);
		
		hmap = new AdoptService().getUpdateView(iNo);
		
		String page ="";
		
		if(result > 0) {
			page = "views/adopt/adoptDetail.jsp";
			request.setAttribute("adopt", hmap.get("adopt"));
			request.setAttribute("fileList", hmap.get("attachment"));
			
		}else {
			page = "views/common/errorPage.jsp";
			request.setAttribute("msg", "파일 전송 실패!");
		}
			request.getRequestDispatcher(page).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
