package com.kh.tmc.adopt.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.adopt.model.service.AdoptService;
import com.kh.tmc.adoptMaching.model.service.MachingService;
import com.kh.tmc.adoptMaching.model.vo.DogTable;
import com.kh.tmc.shelter.model.service.ShelterService;
import com.kh.tmc.shelter.model.vo.Shelter;

/**
 * Servlet implementation class AdoptUpdateView
 */
@WebServlet("/uAdoptView.ado")
public class AdoptUpdateView extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdoptUpdateView() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int iNo = Integer.parseInt(request.getParameter("iNo"));
		ArrayList<Shelter> slist = new ShelterService().selectShelterList();
		ArrayList<DogTable> dlist = new MachingService().selectDogList();
		
//		Adopt adopt = new AdoptService().updateView(iNo);
		
		HashMap<String,Object> hmap 
		= new AdoptService().getUpdateView(iNo);
		
		String page = "";
		
		if(hmap != null && hmap.get("attachment") != null ) {
			
			page = "views/adopt/adoptUpdateView.jsp";
			request.setAttribute("adopt", hmap.get("adopt"));
			request.setAttribute("fileList", hmap.get("attachment"));
			request.setAttribute("slist", slist);
			request.setAttribute("dlist", dlist);
			
		}else {
			page = "views/common/errorPage.jsp";
			request.setAttribute("msg", "게시글 글 수정 페이지 연결 실패 !");
		}
		
		request.getRequestDispatcher(page).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
