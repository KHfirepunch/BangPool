package com.kh.tmc.adopt.model.dao;

import static com.kh.tmc.common.JDBCTemplate.close;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import com.kh.tmc.adopt.model.vo.Adopt;
import com.kh.tmc.adopt.model.vo.Attachment;

public class AdoptDao {
	
	Properties prop = new Properties();
	public AdoptDao() {
		try {
			String filePath = AdoptDao.class.getResource("/config/adopt-query.properties").getPath();
			prop.load(new FileInputStream(filePath));
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	public ArrayList<Adopt> selectAdopt(Connection con, int currentPage, int limit) {
		ArrayList<Adopt> list = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String sql = prop.getProperty("selectAdopt");
		
		try {
			list = new ArrayList<Adopt>();
			pstmt = con.prepareStatement(sql);
			
			// 1. 마지막 행의 번호
			// 2. 첫 행의 번호
			int startRow = (currentPage -1) * limit + 1;  // 1, 11, 21 
			
			int endRow = startRow + limit - 1;  //10, 20, 30
			
			pstmt.setInt(1, endRow);
			pstmt.setInt(2, startRow);
			
			rset = pstmt.executeQuery();
			
			while(rset.next()) {
				Adopt ad = new Adopt();
				// 글번호 제목 사진 이름 품종 작성자 지역 작성일 성별 상태 
				ad.setiNo(rset.getInt("ino"));
				ad.setiTitle(rset.getString("iTitle"));
				ad.setiFileName(rset.getString("CHANGENAME"));
				ad.setiName(rset.getString("iName"));
				ad.setiAnimalBreed(rset.getString("iAnimalBreed"));
				ad.setiWriter(rset.getString("iWriter"));
				ad.setiArea(rset.getString("iArea"));
				ad.setiDate(rset.getDate("iDate"));
				ad.setiGender(rset.getString("iGender"));
				ad.setiState(rset.getString("iSTATE"));
				
				list.add(ad);	
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
		}
		return list;
	}
	public int insertAdopt(Connection con, Adopt ad) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("insertAdopt");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, ad.getiTitle());
			pstmt.setString(2, ad.getiWriter());
			pstmt.setString(3, ad.getiName());
			pstmt.setString(4, ad.getiAnimalBreed());
			pstmt.setInt(5, ad.getiAge());
			pstmt.setDouble(6, ad.getiWeith());
			pstmt.setString(7, ad.getShelterName());
			pstmt.setString(8, ad.getiHairColor());
			pstmt.setString(9, ad.getiGender());
			pstmt.setString(10, ad.getiVaccination());
			pstmt.setString(11, ad.getiDefecationTraining());
			pstmt.setString(12, ad.getiContent());
			pstmt.setString(13, ad.getiArea());
			
			result = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}
	
	public int insertAttachment(Connection con, ArrayList<Attachment> list) {
		PreparedStatement pstmt = null;
		int result = 0;
		
		String sql = prop.getProperty("insertAttachment");
		
		try {
			for(int i=0; i<list.size();i++) {
				pstmt = con.prepareStatement(sql);
				
				pstmt.setInt(1, list.get(i).getAno());
				pstmt.setString(2, list.get(i).getOriginname());
				pstmt.setString(3, list.get(i).getChangename());
				pstmt.setString(4, list.get(i).getFilePath());
				// 첫번째로 들어가는 데이터는 대표이미지
				// 나머지는 서브 이미지 -->레벨로 결정
				
				int level = 0;
				if(i !=0) level =1;
				pstmt.setInt(5, level);
				
				result += pstmt.executeUpdate();
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}
	
	public int selectCurrentAno(Connection con) {
		Statement stmt = null;
		ResultSet rset = null;
		
		int result = 0;
		String sql = prop.getProperty("selectLastAno");
		try {
			stmt = con.createStatement();
			rset = stmt.executeQuery(sql);
			
			if(rset.next()) {
				result = rset.getInt(1);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(stmt);
		}
		
		return result;
	}
	public int getListCount(Connection con) {
		int listCount = 0;
		Statement stmt = null;
		ResultSet rset = null;
		
		String sql = prop.getProperty("listCount");
		
		try {
			stmt = con.createStatement();
			
			rset = stmt.executeQuery(sql);
			
			if(rset.next()) {
				listCount = rset.getInt(1);
			}
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(stmt);
			
		}
			
			return listCount;
	}
	public Adopt selectOne(Connection con, int iNo) {
		Adopt adopt = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String sql = prop.getProperty("selectOneAdopt");
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,iNo);
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				adopt = new Adopt();
				
				adopt.setiNo(rset.getInt("INO"));
				adopt.setiTitle(rset.getString("ITITLE"));
				adopt.setiWriter(rset.getString("IWRITER"));
				adopt.setiName(rset.getString("INAME"));
				adopt.setiAnimalBreed(rset.getString("IANIMALBREED"));
				adopt.setiAge(rset.getInt("IAGE"));
				adopt.setiWeith(rset.getDouble("IWEITH"));
				adopt.setShelterName(rset.getString("SHELTERNAME"));
				adopt.setiHairColor(rset.getString("IHAIRCOLOR"));
				adopt.setiGender(rset.getString("IGENDER"));
				adopt.setiVaccination(rset.getString("IVACCINATION"));
				adopt.setiDefecationTraining(rset.getString("IDEFECATIONTRAINING"));
				adopt.setiDate(rset.getDate("IDATE"));
				adopt.setiFileName(rset.getString("IFILENAME"));
				adopt.setiState(rset.getString("ISTATE"));
				adopt.setiContent(rset.getString("ICONTENT"));
				adopt.setiArea(rset.getString("IAREA"));
				
				//System.out.println(adopt);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			close(rset);
			close(con);
		}
		
		return adopt;
	}
	
	public int updateAdopt(Connection con, Adopt adopt) {
		PreparedStatement pstmt = null;
		int result = 0;
		
		String sql = prop.getProperty("updateAdopt");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, adopt.getiTitle());
			pstmt.setString(2, adopt.getiName());
			pstmt.setString(3, adopt.getiAnimalBreed());
			pstmt.setInt(4, adopt.getiAge());
			pstmt.setString(5, adopt.getiArea());
			pstmt.setDouble(6, adopt.getiWeith());
			pstmt.setString(7, adopt.getShelterName());
			pstmt.setString(8, adopt.getiHairColor());
			pstmt.setString(9, adopt.getiGender());
			pstmt.setString(10, adopt.getiVaccination());
			pstmt.setString(11, adopt.getiDefecationTraining());
			pstmt.setInt(12, adopt.getiNo());
			
			result = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}

	public int updateAttachment(Connection con, ArrayList<Attachment> list) {
		
		PreparedStatement pstmt = null;
		int result = 0;
		
		String sql = prop.getProperty("updateAttachment");
		
		try {
			for(int i=0;i<list.size();i++) {
				pstmt = con.prepareStatement(sql);
				
				pstmt.setString(1, list.get(i).getOriginname());
				pstmt.setString(2, list.get(i).getChangename());
				pstmt.setInt(3, list.get(i).getFno());
				
				result += pstmt.executeUpdate();
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}
	
	public int deleteAdopt(Connection con , int iNo) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("deleteAdopt");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, iNo);
			
			result = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
			
		}finally {
			close(pstmt);
		}
		
		return result;
	}
	public int deleteAttachment(Connection con, int iNo) {
		PreparedStatement pstmt = null;
		int result = 0;
		
		String sql = prop.getProperty("deleteAttachment");
		
		try {
			
			pstmt = con.prepareStatement(sql);
				
			pstmt.setInt(1, iNo);
				
			result = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
		
	}
	public HashMap<String, Object> selectAdoptMap(Connection con, int iNo) {
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		ArrayList<Attachment> list = null;
		Adopt adopt = null;
		HashMap<String, Object> hmap = null;
		
		String sql = prop.getProperty("selectOneAdopt");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, iNo);
			
			rset = pstmt.executeQuery();
			
			list = new ArrayList<Attachment>();
			
			if(rset.next()) {
				adopt = new Adopt();
				
				adopt.setiNo(rset.getInt("INO"));
				adopt.setiTitle(rset.getString("ITITLE"));
				adopt.setiWriter(rset.getString("IWRITER"));
				adopt.setiName(rset.getString("INAME"));
				adopt.setiAnimalBreed(rset.getString("IANIMALBREED"));
				adopt.setiAge(rset.getInt("IAGE"));
				adopt.setiWeith(rset.getDouble("IWEITH"));
				adopt.setShelterName(rset.getString("SHELTERNAME"));
				adopt.setiHairColor(rset.getString("IHAIRCOLOR"));
				adopt.setiGender(rset.getString("IGENDER"));
				adopt.setiVaccination(rset.getString("IVACCINATION"));
				adopt.setiDefecationTraining(rset.getString("IDEFECATIONTRAINING"));
				adopt.setiDate(rset.getDate("IDATE"));
				adopt.setiFileName(rset.getString("IFILENAME"));
				adopt.setiState(rset.getString("ISTATE"));
				adopt.setiContent(rset.getString("ICONTENT"));
				adopt.setiArea(rset.getString("IAREA"));
				
				Attachment att = new Attachment();
				
				att.setFno(rset.getInt("FNO"));
				att.setOriginname(rset.getString("ORIGINNAME"));
				att.setChangename(rset.getString("CHANGENAME"));
				att.setFilePath(rset.getString("FILEPATH"));
				att.setUploaddate(rset.getDate("UPLOADDATE"));
				att.setFlevel(rset.getInt("FLEVEL"));
				
				list.add(att);
			}
			
			hmap = new HashMap<String,Object>();
			
			hmap.put("adopt", adopt);
			hmap.put("attachment",list);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		return hmap;
	}
	public ArrayList<Adopt> searchAdopt(Connection con, String s_upr_cd, String s_org_cd, String s_up_kind_cd,
			String s_kind_cd, String state, int currentPage, int limit) {
		// TODO Auto-generated method stub
		ArrayList<Adopt> list = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String sql = null;
		int count = 0;
		
		System.out.println(s_upr_cd);
		System.out.println(s_org_cd);
		System.out.println(s_up_kind_cd);
		System.out.println(s_kind_cd);
		System.out.println(state);
		
		//1234
		if(!s_upr_cd.equals("0") && !s_org_cd.equals("0") && !s_up_kind_cd.equals("0") && !s_kind_cd.equals("0")) {
			sql = prop.getProperty("searchAllCheck");
			System.out.println("1234");
			count=1;
			//12
		}else if(!s_upr_cd.equals("0") && !s_org_cd.equals("0")){
			sql = prop.getProperty("searchAddress");
			System.out.println("12");
			//34
		}else if(!s_up_kind_cd.equals("0") && !s_kind_cd.equals("0")) {
			sql = prop.getProperty("searchAnimal");
			System.out.println("34");
		}else {
			sql = prop.getProperty("searchAdopt");
			System.out.println("hhhhhh");
		}
		
		try {
			list = new ArrayList<Adopt>();
			
			int startRow = (currentPage -1) * limit +1; //1
			
			int endRow = startRow + limit -1; // 10,20
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, s_upr_cd);
			pstmt.setString(2, s_org_cd);
//			pstmt.setString(3, s_up_kind_cd);
			pstmt.setString(3, s_kind_cd);
			pstmt.setString(4, state);
			pstmt.setInt(5, endRow);
			pstmt.setInt(6, startRow);
		
			rset = pstmt.executeQuery();
			
			while(rset.next()) {
			Adopt ad = new Adopt();
			
			ad.setiNo(rset.getInt("INO"));
			ad.setiTitle(rset.getString("ITITLE"));
			ad.setiWriter(rset.getString("IWRITER"));
			ad.setiName(rset.getString("INAME"));
			ad.setiAnimalBreed(rset.getString("IANIMALBREED"));
			ad.setiAge(rset.getInt("IAGE"));
			ad.setiWeith(rset.getDouble("IWEITH"));
			ad.setShelterName(rset.getString("SHELTERNAME"));
			ad.setiHairColor(rset.getString("IHAIRCOLOR"));
			ad.setiGender(rset.getString("IGENDER"));
			ad.setiVaccination(rset.getString("IVACCINATION"));
			ad.setiDefecationTraining(rset.getString("IDEFECATIONTRAINING"));
			ad.setiDate(rset.getDate("IDATE"));
			ad.setiFileName(rset.getString("CHANGENAME"));
			ad.setiState(rset.getString("ISTATE"));
			ad.setiContent(rset.getString("ICONTENT"));
			ad.setiArea(rset.getString("IAREA"));
			
			list.add(ad);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		return list;
	}

}
