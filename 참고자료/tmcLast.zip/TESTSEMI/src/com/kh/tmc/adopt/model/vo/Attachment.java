package com.kh.tmc.adopt.model.vo;

import java.io.Serializable;
import java.sql.Date;

public class Attachment implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 795693589524906207L;

	// DB의 컬럼과 같은 필드 변수 생성
	private int fno;
	private int ano;
	private String originname;
	private String changename;
	private String filePath;
	private int flevel;
	private Date uploaddate;
	private String status;
	
	
	public Attachment() {
		
	}


	public Attachment(int fno, int ano, String originname, String changename, String filePath, int flevel,
			Date uploaddate, String status) {
		super();
		this.fno = fno;
		this.ano = ano;
		this.originname = originname;
		this.changename = changename;
		this.filePath = filePath;
		this.flevel = flevel;
		this.uploaddate = uploaddate;
		this.status = status;
	}


	public int getFno() {
		return fno;
	}


	public void setFno(int fno) {
		this.fno = fno;
	}


	public int getAno() {
		return ano;
	}


	public void setAno(int ano) {
		this.ano = ano;
	}


	public String getOriginname() {
		return originname;
	}


	public void setOriginname(String originname) {
		this.originname = originname;
	}


	public String getChangename() {
		return changename;
	}


	public void setChangename(String changename) {
		this.changename = changename;
	}


	public String getFilePath() {
		return filePath;
	}


	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}


	public int getFlevel() {
		return flevel;
	}


	public void setFlevel(int flevel) {
		this.flevel = flevel;
	}


	public Date getUploaddate() {
		return uploaddate;
	}


	public void setUploaddate(Date uplodadate) {
		this.uploaddate = uplodadate;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public String toString() {
		return "Thumbnail [fno=" + fno + ", ano=" + ano + ", originname=" + originname + ", changename=" + changename
				+ ", filePath=" + filePath + ", flevel=" + flevel + ", uploaddate=" + uploaddate + ", status=" + status
				+ "]";
	}
	
	
	
	
	
	
	
	
}
