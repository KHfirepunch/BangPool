package com.kh.tmc.adopt.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.shelter.model.service.ShelterService;
import com.kh.tmc.shelter.model.vo.Shelter;

/**
 * Servlet implementation class AdoptWriteView
 */
@WebServlet("/iAdoptView.ado")
public class AdoptInsertView extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdoptInsertView() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// 보호소 목록 차트 뽑아오기
		ArrayList<Shelter> slist = new ShelterService().selectShelterList();
				
		String page ="";
		if(slist != null ) {
			
			page = "views/adopt/adoptWrite.jsp";
			request.setAttribute("slist", slist);
			
		}else {
			page = "views/common/errorPage.jsp";
			request.setAttribute("msg", "게시글 글 수정 페이지 연결 실패 !");
		}
		
		request.getRequestDispatcher(page).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
