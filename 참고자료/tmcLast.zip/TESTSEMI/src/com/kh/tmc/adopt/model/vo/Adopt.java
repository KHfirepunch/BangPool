package com.kh.tmc.adopt.model.vo;

import java.io.Serializable;
import java.sql.Date;

public class Adopt implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -205189695505130138L;

	private int iNo;
	private String iTitle;
	private String iWriter;
	private String iName;
	private String iAnimalBreed;
	private int iAge;
	private double iWeith;
	private String shelterName;
	private String iHairColor;
	private String iGender;
	private String iVaccination;
	private String iDefecationTraining;
	private Date iDate;
	private String iFileName;
	private String iState;
	private String iContent;
	private String iArea;
	
	public Adopt() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getiNo() {
		return iNo;
	}

	public void setiNo(int iNo) {
		this.iNo = iNo;
	}

	public String getiTitle() {
		return iTitle;
	}

	public void setiTitle(String iTitle) {
		this.iTitle = iTitle;
	}

	public String getiWriter() {
		return iWriter;
	}

	public void setiWriter(String iWriter) {
		this.iWriter = iWriter;
	}

	public String getiName() {
		return iName;
	}

	public void setiName(String iName) {
		this.iName = iName;
	}

	public String getiAnimalBreed() {
		return iAnimalBreed;
	}

	public void setiAnimalBreed(String iAnimalBreed) {
		this.iAnimalBreed = iAnimalBreed;
	}

	public int getiAge() {
		return iAge;
	}

	public void setiAge(int iAge) {
		this.iAge = iAge;
	}

	public double getiWeith() {
		return iWeith;
	}

	public void setiWeith(double iWeith) {
		this.iWeith = iWeith;
	}

	public String getShelterName() {
		return shelterName;
	}

	public void setShelterName(String shelterName) {
		this.shelterName = shelterName;
	}

	public String getiHairColor() {
		return iHairColor;
	}

	public void setiHairColor(String iHairColor) {
		this.iHairColor = iHairColor;
	}

	public String getiGender() {
		return iGender;
	}

	public void setiGender(String iGender) {
		this.iGender = iGender;
	}

	public String getiVaccination() {
		return iVaccination;
	}

	public void setiVaccination(String iVaccination) {
		this.iVaccination = iVaccination;
	}

	public String getiDefecationTraining() {
		return iDefecationTraining;
	}

	public void setiDefecationTraining(String iDefecationTraining) {
		this.iDefecationTraining = iDefecationTraining;
	}

	public Date getiDate() {
		return iDate;
	}

	public void setiDate(Date iDate) {
		this.iDate = iDate;
	}

	public String getiFileName() {
		return iFileName;
	}

	public void setiFileName(String iFileName) {
		this.iFileName = iFileName;
	}

	public String getiState() {
		return iState;
	}

	public void setiState(String iState) {
		this.iState = iState;
	}

	public String getiContent() {
		return iContent;
	}

	public void setiContent(String iContent) {
		this.iContent = iContent;
	}

	public String getiArea() {
		return iArea;
	}

	public void setiArea(String iArea) {
		this.iArea = iArea;
	}
	
	
	

	public Adopt(String iTitle, String iWriter, String iName, String iAnimalBreed, int iAge, double iWeith,
			String shelterName, String iHairColor, String iGender, String iVaccination, String iDefecationTraining,
			Date iDate, String iFileName, String iContent, String iArea) {
		super();
		this.iTitle = iTitle;
		this.iWriter = iWriter;
		this.iName = iName;
		this.iAnimalBreed = iAnimalBreed;
		this.iAge = iAge;
		this.iWeith = iWeith;
		this.shelterName = shelterName;
		this.iHairColor = iHairColor;
		this.iGender = iGender;
		this.iVaccination = iVaccination;
		this.iDefecationTraining = iDefecationTraining;
		this.iDate = iDate;
		this.iFileName = iFileName;
		this.iContent = iContent;
		this.iArea = iArea;
	}

	public Adopt(int iNo, String iTitle, String iWriter, String iName, String iAnimalBreed, int iAge, double iWeith,
			String shelterName, String iHairColor, String iGender, String iVaccination, String iDefecationTraining,
			Date iDate, String iFileName, String iState, String iContent, String iArea) {
		super();
		this.iNo = iNo;
		this.iTitle = iTitle;
		this.iWriter = iWriter;
		this.iName = iName;
		this.iAnimalBreed = iAnimalBreed;
		this.iAge = iAge;
		this.iWeith = iWeith;
		this.shelterName = shelterName;
		this.iHairColor = iHairColor;
		this.iGender = iGender;
		this.iVaccination = iVaccination;
		this.iDefecationTraining = iDefecationTraining;
		this.iDate = iDate;
		this.iFileName = iFileName;
		this.iState = iState;
		this.iContent = iContent;
		this.iArea = iArea;
	}

	public Adopt(String iTitle, String iWriter, String iName, String iAnimalBreed, int iAge, double iWeith,
			String iHairColor, String iGender, String iVaccination, String iDefecationTraining, String iFileName,
			String iContent, String iArea) {
		super();
		this.iTitle = iTitle;
		this.iWriter = iWriter;
		this.iName = iName;
		this.iAnimalBreed = iAnimalBreed;
		this.iAge = iAge;
		this.iWeith = iWeith;
		this.iHairColor = iHairColor;
		this.iGender = iGender;
		this.iVaccination = iVaccination;
		this.iDefecationTraining = iDefecationTraining;
		this.iFileName = iFileName;
		this.iContent = iContent;
		this.iArea = iArea;
	}

	@Override
	public String toString() {
		return "Adopt [iNo=" + iNo + ", iTitle=" + iTitle + ", iWriter=" + iWriter + ", iName=" + iName
				+ ", iAnimalBreed=" + iAnimalBreed + ", iAge=" + iAge + ", iWeith=" + iWeith + ", shelterName="
				+ shelterName + ", iHairColor=" + iHairColor + ", iGender=" + iGender + ", iVaccination=" + iVaccination
				+ ", iDefecationTraining=" + iDefecationTraining + ", iDate=" + iDate + ", iFileName=" + iFileName
				+ ", iState=" + iState + ", iContent=" + iContent + ", iArea=" + iArea + "]";
	}

	
	
	
	
	

}