package com.kh.tmc.adopt.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import com.kh.tmc.adopt.model.service.AdoptService;
import com.kh.tmc.adopt.model.vo.Adopt;
import com.kh.tmc.adopt.model.vo.Attachment;
import com.kh.tmc.common.MyRenamePolicy;
import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class InsertAdopt
 */
@WebServlet("/iAdopt.ado")
public class AdoptInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdoptInsert() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		AdoptService as = new AdoptService();
		
		if(!ServletFileUpload.isMultipartContent(request)) {
			// 만약Multipart/form-data 로 보내지 않았으면 에러 발생!!!
			
			request.setAttribute("msg", "Multipart/form-data 형식으로 전송해야 합니다.");
			request.getRequestDispatcher("views/common/errorPage.jsp").forward(request, response);
			
			
		}
		
		// 1. 전송할 파일의 크기름 설정
				int maxSize = 1024 * 1024 * 10;
				
				// 2. 저장할 경로 설정하기
				String root 
				 = request.getServletContext().getRealPath("resourse");
				
				String savePath = root + "/adoptUploadFiles";
				
				MultipartRequest mrequest
				 = new MultipartRequest(request,savePath,maxSize,"UTF-8",new MyRenamePolicy());
				
				// 다중 파일 업로드 사에 처리하는 방법
				// 다중 파일 업로드 시 컬렉션 객체를 활용하여 파일을 별도 관리 한다.
				
				// 변경된 파일명
				ArrayList<String> saveFiles = new ArrayList<String>();
				
				// 원본 파일명
				ArrayList<String> originFiles = new ArrayList<String>();
				
				Enumeration<String> files
				 = mrequest.getFileNames();
				
				while(files.hasMoreElements()) {
					// 각 파일의 정보를 가져와 DB에 저장
					String name = files.nextElement();
					
					saveFiles.add(mrequest.getFilesystemName(name));
					originFiles.add(mrequest.getOriginalFileName(name));
					
				}
				
				// Thumbnail VO 객체 생성 -> DB에 전달
				Adopt ad = new Adopt();
				
				ad.setiTitle(mrequest.getParameter("adoptTitle"));
				ad.setiWriter(mrequest.getParameter("adoptWriter"));
				ad.setiName(mrequest.getParameter("iName"));
				ad.setiAnimalBreed(mrequest.getParameter("iAnimalBreed"));
				ad.setiAge(Integer.parseInt(mrequest.getParameter("iAge")));
				ad.setiArea(mrequest.getParameter("iArea"));
				ad.setiWeith(Double.parseDouble(mrequest.getParameter("iWeith")));
				ad.setShelterName(mrequest.getParameter("shelterName"));
				ad.setiHairColor(mrequest.getParameter("iHairColor"));
				ad.setiGender(mrequest.getParameter("iGender"));
				ad.setiVaccination(mrequest.getParameter("iVaccination"));
				ad.setiDefecationTraining(mrequest.getParameter("iDefecationTraining"));
				ad.setiContent(mrequest.getParameter("iContent"));
				ad.setiState("Y");
				
				// Attachment 객체에 파일 정보를 저장 --> ArrayList 생성
				ArrayList<Attachment>list = new ArrayList<Attachment>();
				
				// 리스트에 파일 목록 하나씩 저장 하자
				for(int i= originFiles.size() -1; i>=0; i--	) {
					// 기존에 역순으로 저장된 파일 리스트를 올바른 순서를 재정렬하기
					Attachment at = new Attachment();
					at.setFilePath(savePath);
					at.setOriginname(originFiles.get(i));
					at.setChangename(saveFiles.get(i));
					
					list.add(at);
					
				}
				int result = as.insertAdopt(ad,list);
				
				
				if(result >0) {
					response.sendRedirect("listAdopt.ado");
					
				}else {
					request.setAttribute("msg", "파일 전송 실패!!");
					
					// 이전 파일 정보 삭제하기
					for(int i=0; i<saveFiles.size(); i++) {
						File file = new File(savePath + saveFiles.get(i));
						
					}
					
				}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
