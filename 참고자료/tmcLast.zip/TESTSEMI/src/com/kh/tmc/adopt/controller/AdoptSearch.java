package com.kh.tmc.adopt.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.adopt.model.service.AdoptService;
import com.kh.tmc.adopt.model.vo.Adopt;
import com.kh.tmc.adopt.model.vo.PageInfo;

/**
 * Servlet implementation class AdoptSearch
 */
@WebServlet("/searchAdopt.ado")
public class AdoptSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdoptSearch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 검색 카테고리 
		
		// 시도
		String s_upr_cd = request.getParameter("s_upr_cd");
		// 시군구
		String s_org_cd = request.getParameter("s_org_cd");
		// 축종
		String s_up_kind_cd = request.getParameter("s_up_kind_cd");
		// 종
		String s_kind_cd = request.getParameter("s_kind_cd");
		// 상태
		String state = request.getParameter("s_state");
		
		ArrayList<Adopt> list = new ArrayList<Adopt>();
		AdoptService as = new AdoptService();
		
		int startPage;
		
		int endPage;
		
		int maxPage;
		
		int currentPage = 1;
		
		int limit =10;
		
		if(request.getParameter("currentPage") != null) {
			currentPage = Integer.parseInt(request.getParameter("currentPage"));
		}
		
		int listCount = as.getListCount();
		
		maxPage = (int)((double)listCount/limit +  0.9);	
		
		startPage = ((int)((double)currentPage / limit+0.9) -1)* limit + 1;
		
		endPage = startPage + limit -1;
		
		if(endPage>maxPage) {
			endPage = maxPage;
		}
		
		list = as.searchAdopt(s_upr_cd,s_org_cd,s_up_kind_cd,s_kind_cd,state,currentPage,limit);
		System.out.println(list);
		String page = "";
		if(list != null) {
			page = "views/adopt/adopt.jsp";
			request.setAttribute("list", list);
			
			PageInfo pi = new PageInfo(currentPage, listCount, limit,maxPage,startPage,endPage);
			request.setAttribute("pi", pi);
						
		}else {
			page = "views/common/errorPage.jsp";
			request.setAttribute("msg", "공지사항 검색 실패!");
			
		}
		request.getRequestDispatcher(page).forward(request, response);
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
