package com.kh.tmc.adopt.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.adopt.model.service.AdoptService;
import com.kh.tmc.adoptComment.model.service.AdoptCommentService;
import com.kh.tmc.adoptComment.model.vo.AdoptComment;
import com.kh.tmc.shelter.model.service.ShelterService;
import com.kh.tmc.shelter.model.vo.Shelter;

/**
 * Servlet implementation class AdoptSelectOne
 */
@WebServlet("/soAdopt.ado")
public class AdoptSelectOne extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdoptSelectOne() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int iNo = Integer.parseInt(request.getParameter("iNo"));
//		ArrayList<AdoptComment> iCommentlist = 
//				new AdoptCommentService().selectAdoptCommentList(iNo);
		
		// 보호소 목록 차트 뽑아오기
		ArrayList<Shelter> slist = new ShelterService().selectShelterList();
		
		HashMap<String,Object> map = new AdoptService().selectAdoptMap(iNo);
		
		ArrayList<AdoptComment> iCommentlist = 
				new AdoptCommentService().selectAdoptCommentList(iNo);
		
		String page = "";
		if(map != null && map.get("attachment") != null) {
			page = "views/adopt/adoptDetail.jsp";
			request.setAttribute("adopt", map.get("adopt"));
			request.setAttribute("fileList", map.get("attachment"));
			request.setAttribute("slist", slist);
			request.setAttribute("iclist", iCommentlist); // 댓글
			
		}else {
			page = "views/common/errorPage.jsp";
			request.setAttribute("msg", "게시글 상세보기 실패!");
		}
		
		request.getRequestDispatcher(page).forward(request, response);
		
		
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
