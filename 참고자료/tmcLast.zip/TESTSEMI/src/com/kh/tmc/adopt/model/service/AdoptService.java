package com.kh.tmc.adopt.model.service;

import static com.kh.tmc.common.JDBCTemplate.close;
import static com.kh.tmc.common.JDBCTemplate.commit;
import static com.kh.tmc.common.JDBCTemplate.getConnection;
import static com.kh.tmc.common.JDBCTemplate.rollback;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import com.kh.tmc.adopt.model.dao.AdoptDao;
import com.kh.tmc.adopt.model.vo.Adopt;
import com.kh.tmc.adopt.model.vo.Attachment;

public class AdoptService {
	AdoptDao aDao = new AdoptDao();
	
	public ArrayList<Adopt> selectAdopt(int currentPage, int limit) {
		Connection con = getConnection();
		
		ArrayList<Adopt> list = aDao.selectAdopt(con,currentPage,limit);
		
		close(con);
		
		return list;
	}

	public int insertAdopt(Adopt ad, ArrayList<Attachment> list) {
		Connection con = getConnection();
		
		int result =0;

		int result1 = aDao.insertAdopt(con,ad);
		
		if(result1 > 0) {
			// 갯수가 몇개 인지 확인
			int ano = aDao.selectCurrentAno(con);
			
			for(int i=0; i<list.size(); i++) {
				list.get(i).setAno(ano);
			}
		}
		// 2. 첨부파일 여러개 추가 쿼리 실행
		int result2 = aDao.insertAttachment(con,list);
		
		if(result1 > 0 && result2 > 0) {
			commit(con);
			result = 1;
		}else {
			rollback(con);
		}
		close(con);
		
		
		return result;
	}

	public int getListCount() {
		Connection con = getConnection();
		
		int listCount = aDao.getListCount(con);
		
		close(con);
		return listCount;
	}

	public Adopt selectOne(int iNo) {
		Connection con = getConnection();
		
		Adopt adopt = aDao.selectOne(con,iNo); 
				
		close(con);
		
		return adopt;
	}

	public int deleteAdopt(int iNo) {
		Connection con = getConnection();
		int result = 0;
		
		int result1 = aDao.deleteAdopt(con,iNo);
		
		if(result1>0) {
			int result2 = aDao.deleteAttachment(con, iNo);
			
			if(result2>0) {
				commit(con);
				result = 1;
			}
			else rollback(con);
			
		}
		
		close(con);
		
		return result;
	}

	public Adopt updateView(int iNo) {
		Connection con = getConnection();
		
		Adopt adopt = aDao.selectOne(con, iNo);
		
		close(con);
		
		return adopt;
	}

	public HashMap<String, Object> getUpdateView(int iNo) {
		Connection con = getConnection();
		
		HashMap<String,Object> hmap 
		= aDao.selectAdoptMap(con,iNo);
		
		close(con);
		
		return hmap;
	}

	public HashMap<String, Object> selectAdoptMap(int iNo) {
		Connection con = getConnection();
		
		HashMap<String,Object> hmap = null;
		
		hmap = aDao.selectAdoptMap(con,iNo);
		close(con);
		
		return hmap;
	}

	public int updateAdopt(Adopt adopt, ArrayList<Attachment> list) {
		int result = 0;
		
		Connection con = getConnection();
		
		int result1 = aDao.updateAdopt(con,adopt);
		
		if(result1 > 0) {
			int result2 = aDao.updateAttachment(con,list);
			
			if(result2 > 0) {
				commit(con);
				result = 1;
			}else {
				rollback(con);
			}
		}
		
		close(con);
		return result;
	}

	public ArrayList<Adopt> searchAdopt(String s_upr_cd, String s_org_cd, String s_up_kind_cd, String s_kind_cd,
			String state, int currentPage, int limit) {
		
		Connection con = getConnection();
		
		ArrayList<Adopt> list= aDao.searchAdopt(con,s_upr_cd,s_org_cd,s_up_kind_cd,s_kind_cd,state,currentPage,limit);
		
		close(con);
		return list;
	}



}
