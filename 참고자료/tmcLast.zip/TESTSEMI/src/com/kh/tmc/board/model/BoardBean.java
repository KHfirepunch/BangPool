package com.kh.tmc.board.model;

import java.sql.Date;

public class BoardBean 
{
	private int number;
	private int board_num;  		// 湲�踰덊샇
	private int rnum;  		// 湲�踰덊샇
	private String board_id; 		// 湲� �옉�꽦�옄
	private String board_subject; 	// 湲� �젣紐�
	private String board_content; 	// 湲� �궡�슜
	private String board_file; 		// 泥⑤��뙆�씪 �씠由�
	private int board_count; 		// 湲� 議고쉶�닔
	private Date board_date; 		// 湲� �옉�꽦�씪
	
	
	public int getBoard_num() {
		return board_num;
	}
	public void setBoard_num(int board_num) {
		this.board_num = board_num;
	}
	public String getBoard_id() {
		return board_id;
	}
	public void setBoard_id(String board_id) {
		this.board_id = board_id;
	}
	public String getBoard_subject() {
		return board_subject;
	}
	public void setBoard_subject(String board_subject) {
		this.board_subject = board_subject;
	}
	public String getBoard_content() {
		return board_content;
	}
	public void setBoard_content(String board_content) {
		this.board_content = board_content;
	}
	public String getBoard_file() {
		return board_file;
	}
	public void setBoard_file(String board_file) {
		this.board_file = board_file;
	}


	public int getBoard_count() {
		return board_count;
	}
	public void setBoard_count(int board_count) {
		this.board_count = board_count;
	}
	public Date getBoard_date() {
		return board_date;
	}
	public void setBoard_date(Date board_date) {
		this.board_date = board_date;
	}
	public int getRnum() {
		return rnum;
	}
	public void setRnum(int rnum) {
		this.rnum = rnum;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
}
