package com.kh.tmc.board.comment.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.board.comment.model.CommentBean;
import com.kh.tmc.board.comment.model.CommentDAO;
import com.kh.tmc.common.action.Action;
import com.kh.tmc.common.action.ActionForward;

public class CommentReplyFormAction implements Action
{
	@Override
	public ActionForward execute(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		ActionForward forward = new ActionForward();
		
		// �θ���� �۹�ȣ�� �����´�.
		int comment_num = Integer.parseInt(request.getParameter("num"));

		CommentDAO dao = CommentDAO.getInstance();
		CommentBean comment = dao.getComment(comment_num);
		
		// ��� ������ request�� �����Ѵ�.
		request.setAttribute("comment", comment);
		
		forward.setRedirect(false);
		forward.setNextPath("/views/board/comment/CommentReplyForm.jsp");

		return forward;
	}
}
