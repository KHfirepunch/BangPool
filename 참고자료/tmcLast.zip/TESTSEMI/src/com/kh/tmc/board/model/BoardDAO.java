package com.kh.tmc.board.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.kh.tmc.common.JDBCTemplate;

public class BoardDAO {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private static BoardDAO instance;

	private BoardDAO() {
	}

	public static BoardDAO getInstance() {
		if (instance == null)
			instance = new BoardDAO();
		return instance;
	}

	// �떆���뒪瑜� 媛��졇�삩�떎.
	public int getSeq() {
		int result = 1;

		try {
			conn = JDBCTemplate.getConnection();

			// �떆���뒪 媛믪쓣 媛��졇�삩�떎. (DUAL : �떆���뒪 媛믪쓣 媛��졇�삤湲곗쐞�븳 �엫�떆 �뀒�씠釉�)
			StringBuffer sql = new StringBuffer();
			sql.append("SELECT BOARD_NUM_UP.NEXTVAL FROM DUAL");

			pstmt = conn.prepareStatement(sql.toString());
			// 荑쇰━ �떎�뻾
			rs = pstmt.executeQuery();

			if (rs.next())
				result = rs.getInt(1);

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

		close();
		return result;
	} // end getSeq

	// 湲� �궫�엯
	public boolean boardInsert(BoardBean board) {
		boolean result = false;

		try {
			conn = JDBCTemplate.getConnection();

			// �옄�룞 而ㅻ컠�쓣 false濡� �븳�떎.
			conn.setAutoCommit(false);

			StringBuffer sql = new StringBuffer();
			sql.append("INSERT INTO FREE_BOARD");
			sql.append("(BOARD_NUM, BOARD_ID, BOARD_SUBJECT, BOARD_CONTENT, BOARD_FILE");
			sql.append(",BOARD_COUNT, BOARD_DATE)");
			sql.append(" VALUES(?,?,?,?,?,?,sysdate)");

			int num = board.getBoard_num(); // 湲�踰덊샇(�떆���뒪 媛�)

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, num);
			pstmt.setString(2, board.getBoard_id());
			pstmt.setString(3, board.getBoard_subject());
			pstmt.setString(4, board.getBoard_content());
			pstmt.setString(5, board.getBoard_file());
			pstmt.setInt(6, board.getBoard_count());

			int flag = pstmt.executeUpdate();
			if (flag > 0) {
				result = true;
				conn.commit(); // �셿猷뚯떆 而ㅻ컠
			}

		} catch (Exception e) {
			try {
				conn.rollback();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

		close();
		return result;
	} // end boardInsert();

	// 湲�紐⑸줉 媛��졇�삤湲�
	public ArrayList<BoardBean> getBoardList(HashMap<String, Object> listOpt) {
		ArrayList<BoardBean> list = new ArrayList<BoardBean>();
		
		String opt = (String) listOpt.get("opt");
		System.out.println("湲� 紐⑸줉�쓣 媛��졇�샃�땲�떎          :"+listOpt);
		System.out.println("listOpt.size()          :"+listOpt.size());
		System.out.println("listOpt.toString()          :"+listOpt.toString());
		System.out.println("listOpt.isEmpty()          :"+listOpt.isEmpty());
		String condition = (String) listOpt.get("condition");
		int start = (Integer) listOpt.get("start");
		try {
			conn = JDBCTemplate.getConnection();
			StringBuffer sql = new StringBuffer();
			System.out.println("BoardDAO�뿉 湲� 紐⑸줉 媛��졇�삤湲� �떎�뻾�맖");
			System.out.println("BoardDAO�뿉 opt         "+opt);
			// 湲�紐⑸줉 �쟾泥대�� 蹂댁뿬以� �븣
			if (opt == null) {
				/*
				 * SELECT * FROM (SELECT ROWNUM AS rnum, data.* FROM (SELECT LEVEL, BOARD_NUM,
				 * BOARD_ID, BOARD_SUBJECT, BOARD_CONTENT, BOARD_FILE, BOARD_COUNT,
				 * BOARD_RE_REF, BOARD_PARENT, BOARD_DATE FROM FREE_BOARD START WITH
				 * BOARD_PARENT = 0 CONNECT BY PRIOR BOARD_NUM = BOARD_PARENT ORDER SIBLINGS BY
				 * BOARD_RE_REF desc) data) WHERE rnum>=? and rnum<=? ;
				 */
			
				sql.append("SELECT * FROM (");
				sql.append("SELECT ROWNUM AS rnum, A.* ");
				sql.append("FROM (");
				sql.append("    SELECT B.* ");
				sql.append("    FROM FREE_BOARD B ");
				sql.append("    ORDER BY BOARD_DATE DESC) A ");
				sql.append(")WHERE rnum>= ? and rnum<= ?");
				sql.append("ORDER BY rnum ASC");

				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setInt(1, start);
				pstmt.setInt(2, start + 9);

				// StringBuffer瑜� 鍮꾩슫�떎.
				sql.delete(0, sql.toString().length());
			} else if (opt.equals("0")) // �젣紐⑹쑝濡� 寃��깋
			{
				sql.append("SELECT * FROM (");
				sql.append("SELECT ROWNUM AS rnum, A.* ");
				sql.append("FROM (");
				sql.append("    SELECT B.* ");
				sql.append("    FROM FREE_BOARD B ");
				sql.append("WHERE BOARD_SUBJECT like ?");
				sql.append("    ORDER BY BOARD_DATE DESC) A ");
				sql.append(")WHERE rnum>=? and rnum<=?");
				sql.append("ORDER BY rnum ASC");

				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setString(1, "%" + condition + "%");
				pstmt.setInt(2, start);
				pstmt.setInt(3, start + 9);

				sql.delete(0, sql.toString().length());
			} else if (opt.equals("1")) // �궡�슜�쑝濡� 寃��깋
			{
				sql.append("SELECT * FROM (");
				sql.append("SELECT ROWNUM AS rnum, A.* ");
				sql.append("FROM (");
				sql.append("    SELECT B.* ");
				sql.append("    FROM FREE_BOARD B ");
				sql.append("WHERE BOARD_CONTENT like ?");
				sql.append("    ORDER BY BOARD_DATE DESC) A ");
				sql.append(")WHERE rnum>=? and rnum<=?");
				sql.append("ORDER BY rnum ASC");

				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setString(1, "%" + condition + "%");
				pstmt.setInt(2, start);
				pstmt.setInt(3, start + 9);

				sql.delete(0, sql.toString().length());
			} else if (opt.equals("2")) // �젣紐�+�궡�슜�쑝濡� 寃��깋
			{
				sql.append("SELECT * FROM (");
				sql.append("SELECT ROWNUM AS rnum, A.* ");
				sql.append("FROM (");
				sql.append("    SELECT B.* ");
				sql.append("    FROM FREE_BOARD B ");
				sql.append("WHERE BOARD_SUBJECT like ?");
				sql.append("OR BOARD_CONTENT like ?");
				sql.append("    ORDER BY BOARD_DATE DESC) A ");
				sql.append(")WHERE rnum>=? and rnum<=?");
				sql.append("ORDER BY rnum ASC");

				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setString(1, "%" + condition + "%");
				pstmt.setString(2, "%" + condition + "%");
				pstmt.setInt(3, start);
				pstmt.setInt(4, start + 9);

				sql.delete(0, sql.toString().length());
			} else if (opt.equals("3")) // 湲��벖�씠濡� 寃��깋
			{
				sql.append("SELECT * FROM (");
				sql.append("SELECT ROWNUM AS rnum, A.* ");
				sql.append("FROM (");
				sql.append("    SELECT B.* ");
				sql.append("    FROM FREE_BOARD B ");
				sql.append("WHERE BOARD_ID like ?");
				sql.append("    ORDER BY BOARD_DATE DESC) A ");
				sql.append(")WHERE rnum>=? and rnum<=?");
				sql.append("ORDER BY rnum ASC");

				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setString(1, "%" + condition + "%");
				pstmt.setInt(2, start);
				pstmt.setInt(3, start + 9);

				sql.delete(0, sql.toString().length());
			}

			ResultSet rs1 = pstmt.executeQuery();
			while (rs1.next()) {
				BoardBean board = new BoardBean();
				board.setNumber(rs1.getInt("RNUM"));
				board.setBoard_num(rs1.getInt("BOARD_NUM"));
				board.setBoard_id(rs1.getString("BOARD_ID"));
				board.setBoard_subject(rs1.getString("BOARD_SUBJECT"));
				board.setBoard_content(rs1.getString("BOARD_CONTENT"));
				board.setBoard_file(rs1.getString("BOARD_FILE"));
				board.setBoard_count(rs1.getInt("BOARD_COUNT"));
				board.setBoard_date(rs1.getDate("BOARD_DATE"));
				list.add(board);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

		close();
		System.out.println(list);
		return list;
	} // end getBoardList

	// 湲��쓽 媛쒖닔瑜� 媛��졇�삤�뒗 硫붿꽌�뱶
	public int getBoardListCount(HashMap<String, Object> listOpt) {
		int result = 0;
		String opt = (String) listOpt.get("opt");
		String condition = (String) listOpt.get("condition");

		try {
			conn = JDBCTemplate.getConnection();
			StringBuffer sql = new StringBuffer();

			if (opt == null) // �쟾泥닿��쓽 媛쒖닔
			{
				sql.append("select count(*) from FREE_BOARD");
				pstmt = conn.prepareStatement(sql.toString());

				// StringBuffer瑜� 鍮꾩슫�떎.
				sql.delete(0, sql.toString().length());
			} else if (opt.equals("0")) // �젣紐⑹쑝濡� 寃��깋�븳 湲��쓽 媛쒖닔
			{
				sql.append("select count(*) from FREE_BOARD where BOARD_SUBJECT like ?");
				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setString(1, '%' + condition + '%');

				sql.delete(0, sql.toString().length());
			} else if (opt.equals("1")) // �궡�슜�쑝濡� 寃��깋�븳 湲��쓽 媛쒖닔
			{
				sql.append("select count(*) from FREE_BOARD where BOARD_CONTENT like ?");
				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setString(1, '%' + condition + '%');

				sql.delete(0, sql.toString().length());
			} else if (opt.equals("2")) // �젣紐�+�궡�슜�쑝濡� 寃��깋�븳 湲��쓽 媛쒖닔
			{
				sql.append("select count(*) from FREE_BOARD ");
				sql.append("where BOARD_SUBJECT like ? or BOARD_CONTENT like ?");
				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setString(1, '%' + condition + '%');
				pstmt.setString(2, '%' + condition + '%');

				sql.delete(0, sql.toString().length());
			} else if (opt.equals("3")) // 湲��벖�씠濡� 寃��깋�븳 湲��쓽 媛쒖닔
			{
				sql.append("select count(*) from FREE_BOARD where BOARD_ID like ?");
				pstmt = conn.prepareStatement(sql.toString());
				pstmt.setString(1, '%' + condition + '%');

				sql.delete(0, sql.toString().length());
			}

			rs = pstmt.executeQuery();
			if (rs.next())
				result = rs.getInt(1);

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

		close();
		return result;
	} // end getBoardListCount

	// �긽�꽭蹂닿린
	public BoardBean getDetail(int boardNum) {
		BoardBean board = null;

		try {
			conn = JDBCTemplate.getConnection();

			StringBuffer sql = new StringBuffer();
			sql.append("select * from FREE_BOARD where BOARD_NUM = ?");

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, boardNum);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				board = new BoardBean();
				board.setBoard_num(boardNum);
				board.setBoard_id(rs.getString("BOARD_ID"));
				board.setBoard_subject(rs.getString("BOARD_SUBJECT"));
				board.setBoard_content(rs.getString("BOARD_CONTENT"));
				board.setBoard_file(rs.getString("BOARD_FILE"));
				board.setBoard_count(rs.getInt("BOARD_COUNT"));
				board.setBoard_date(rs.getDate("BOARD_DATE"));
			}

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

		close();
		return board;
	} // end getDetail()

	// 議고쉶�닔 利앷�
	public boolean updateCount(int boardNum) {
		boolean result = false;

		try {
			conn = JDBCTemplate.getConnection();

			// �옄�룞 而ㅻ컠�쓣 false濡� �븳�떎.
			conn.setAutoCommit(false);

			StringBuffer sql = new StringBuffer();
			sql.append("update FREE_BOARD set BOARD_COUNT = BOARD_COUNT+1 ");
			sql.append("where BOARD_NUM = ?");

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, boardNum);

			int flag = pstmt.executeUpdate();
			if (flag > 0) {
				result = true;
				conn.commit(); // �셿猷뚯떆 而ㅻ컠
			}
		} catch (Exception e) {
			try {
				conn.rollback(); // �삤瑜섏떆 濡ㅻ갚
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
			throw new RuntimeException(e.getMessage());
		}

		close();
		return result;
	} // end updateCount

	// �궘�젣�븷 �뙆�씪紐낆쓣 媛��졇�삩�떎.
	public String getFileName(int boardNum) {
		String fileName = null;

		try {
			conn = JDBCTemplate.getConnection();

			StringBuffer sql = new StringBuffer();
			sql.append("SELECT BOARD_FILE from FREE_BOARD where BOARD_NUM=?");

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, boardNum);

			rs = pstmt.executeQuery();
			if (rs.next())
				fileName = rs.getString("BOARD_FILE");

		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

		close();
		return fileName;
	} // end getFileName

	// 寃뚯떆湲� �궘�젣
	public boolean deleteBoard(int boardNum) {
		boolean result = false;

		try {
			conn = JDBCTemplate.getConnection();
			conn.setAutoCommit(false); // �옄�룞 而ㅻ컠�쓣 false濡� �븳�떎.

			StringBuffer sql = new StringBuffer();
			sql.append("DELETE FROM FREE_BOARD ");
			sql.append(" WHERE board_num = ? ");

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, boardNum);

			int flag = pstmt.executeUpdate();
			if (flag > 0) {
				result = true;
				conn.commit(); // �셿猷뚯떆 而ㅻ컠
			}

		} catch (Exception e) {
			try {
				conn.rollback(); // �삤瑜섏떆 濡ㅻ갚
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
			throw new RuntimeException(e.getMessage());
		}

		close();
		return result;
	} // end deleteBoard

	/*
	 * �닔�젙 硫붿꽌�뱶瑜� 湲곗〈 DAO�뿉 異붽��븳�떎.
	 */

	// 湲� �닔�젙
	public boolean updateBoard(BoardBean border) {
		boolean result = false;

		try {
			conn = JDBCTemplate.getConnection();
			conn.setAutoCommit(false); // �옄�룞 而ㅻ컠�쓣 false濡� �븳�떎.

			StringBuffer sql = new StringBuffer();
			sql.append("UPDATE FREE_BOARD SET");
			sql.append(" BOARD_SUBJECT=?");
			sql.append(" ,BOARD_CONTENT=?");
			sql.append(" ,BOARD_FILE=?");
			sql.append(" ,BOARD_DATE=SYSDATE ");
			sql.append("WHERE BOARD_NUM=?");

			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, border.getBoard_subject());
			pstmt.setString(2, border.getBoard_content());
			pstmt.setString(3, border.getBoard_file());
			pstmt.setInt(4, border.getBoard_num());

			int flag = pstmt.executeUpdate();
			if (flag > 0) {
				result = true;
				conn.commit(); // �셿猷뚯떆 而ㅻ컠
			}

		} catch (Exception e) {
			try {
				conn.rollback(); // �삤瑜섏떆 濡ㅻ갚
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
			throw new RuntimeException(e.getMessage());
		}

		close();
		return result;
	} // end updateBoard

	// DB �옄�썝�빐�젣
	private void close() {
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	} // end close()
}
