package com.kh.tmc.shelter.model.service;

import static com.kh.tmc.common.JDBCTemplate.close;
import static com.kh.tmc.common.JDBCTemplate.commit;
import static com.kh.tmc.common.JDBCTemplate.getConnection;
import static com.kh.tmc.common.JDBCTemplate.rollback;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.tmc.notice.model.vo.Notice;
import com.kh.tmc.shelter.model.dao.ShelterDao;
import com.kh.tmc.shelter.model.vo.Shelter;

public class ShelterService {
	
	private ShelterDao sDao = new ShelterDao();

	public Shelter selectOne(int sno) {
		
		Connection con = getConnection();
		// 상세내용
		Shelter s = sDao.selectOne(con,sno);
		
		close(con);
		
		return s;
	}
	
	public ArrayList<Shelter> selectShelterList() {
		Connection con = getConnection();
		// 상세내용
		ArrayList<Shelter> slist = sDao.selectAll(con);
		
		close(con);
		
		return slist;
	}
	

}
