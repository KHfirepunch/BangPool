package com.kh.tmc.shelter.model.dao;

import static com.kh.tmc.common.JDBCTemplate.close;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.tmc.notice.model.vo.Notice;
import com.kh.tmc.shelter.model.vo.Shelter;

public class ShelterDao {
	
private Properties prop;
	
	public ShelterDao() {
		prop = new Properties();
		
		String filePath = ShelterDao.class.getResource("/config/shelter-query.properties").getPath();
		
		try {
			prop.load(new FileReader(filePath));
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

	public Shelter selectOne(Connection con, int sno) {
		Shelter s = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String sql = prop.getProperty("selectOne");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, sno);
			
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				
				s = new Shelter();
				
				s.setsNo(sno);
				s.setsName(rset.getString("SNAME"));
				s.setsAddress(rset.getString("SADDRESS"));
				s.setsPhone(rset.getString("SPHONE"));
			}
			
			System.out.println("shelter 확인 : "+s);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		return s;
	}
	public ArrayList<Shelter> selectAll(Connection con) {
		ArrayList<Shelter> slist = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String sql = prop.getProperty("selectList");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			rset = pstmt.executeQuery();
			slist = new ArrayList<Shelter>();
			
			while(rset.next()) {
				Shelter s = new Shelter();
				
				s.setsNo(rset.getInt("SNO"));
				s.setsName(rset.getString("SNAME"));
				s.setsAddress(rset.getString("SADDRESS"));
				s.setsPhone(rset.getString("SPHONE"));
				
				slist.add(s);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		return slist;
	}
		
		

}
