package com.kh.tmc.shelter.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.notice.model.service.NoticeService;
import com.kh.tmc.notice.model.vo.Notice;
import com.kh.tmc.shelter.model.service.ShelterService;
import com.kh.tmc.shelter.model.vo.Shelter;

/**
 * Servlet implementation class ShelterServlet
 */
@WebServlet("/shelterList.so")
public class ShelterSelectOneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShelterSelectOneServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int sno = Integer.parseInt(request.getParameter("sno"));
		
		ShelterService ss = new ShelterService();
		
		Shelter s = ss.selectOne(sno);
		
		String page = "";
		
		if(s!=null) {
			page="views/notice/####.jsp";
			request.setAttribute("shelter", s);
		}else {
			page="views/common/errorPage.jsp";
			request.setAttribute("msg", "공지사항 상세 보기 실패!");
		}
		
		request.getRequestDispatcher(page).forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
