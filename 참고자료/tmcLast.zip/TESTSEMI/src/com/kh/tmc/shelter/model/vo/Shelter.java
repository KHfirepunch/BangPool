package com.kh.tmc.shelter.model.vo;

import java.io.Serializable;

public class Shelter implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4971004372763125649L;

	private int sNo;
	private String sName;
	private String sAddress;
	private String sPhone;
	
	public Shelter() {}

	public Shelter(int sNo, String sName, String sAddress, String sPhone) {
		super();
		this.sNo = sNo;
		this.sName = sName;
		this.sAddress = sAddress;
		this.sPhone = sPhone;
	}

	public int getsNo() {
		return sNo;
	}

	public void setsNo(int sNo) {
		this.sNo = sNo;
	}

	public String getsName() {
		return sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}

	public String getsAddress() {
		return sAddress;
	}

	public void setsAddress(String sAddress) {
		this.sAddress = sAddress;
	}

	public String getsPhone() {
		return sPhone;
	}

	public void setsPhone(String sPhone) {
		this.sPhone = sPhone;
	}

	@Override
	public String toString() {
		return "Shelter [sNo=" + sNo + ", sName=" + sName + ", sAddress=" + sAddress + ", sPhone=" + sPhone + "]";
	}

	
	
	
	
	
	
}
