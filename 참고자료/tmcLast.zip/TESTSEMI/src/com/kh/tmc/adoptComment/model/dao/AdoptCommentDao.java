package com.kh.tmc.adoptComment.model.dao;

import static com.kh.tmc.common.JDBCTemplate.close;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.tmc.adoptComment.model.dao.AdoptCommentDao;
import com.kh.tmc.adoptComment.model.vo.AdoptComment;

public class AdoptCommentDao {
Properties prop = new Properties();
	
	public AdoptCommentDao() {
		
		String filePath = AdoptCommentDao.class.getResource("/config/adoptComment-query.properties").getPath();
	
		try{
			prop.load(new FileReader(filePath)); 
		}catch(IOException e){
			e.printStackTrace();
		}
	}

	public int deleteComment(Connection con, AdoptComment awc) {
		int result= 0;
		
		PreparedStatement pstmt = null;
		
		String sql = prop.getProperty("deleteAdoptComment");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, awc.getiNo());
			pstmt.setInt(2, awc.getIcNo());
			
			
			result = pstmt.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		return result;
	}

	public int insertAdoptCommentInsert(Connection con, AdoptComment awc) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("insertAdoptComment");
		
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, awc.getiNo());
			pstmt.setString(2, awc.getIcContent());
			pstmt.setString(3, awc.getIcWriter());
			
			if(awc.getIcRefno()>0) {
				pstmt.setInt(4, awc.getIcRefno());
			}else {
				pstmt.setInt(4, java.sql.Types.NULL );
			}
			
			pstmt.setInt(5, awc.getIcLevel());
			
			result = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			close(pstmt);
		}
		
		
		return result;
	}

	public ArrayList<AdoptComment> selectAdoptCommentList(Connection con, int iNo) {
		ArrayList<AdoptComment> wisCommentList= null;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("selectAdoptCommentList");
		ResultSet rset = null;
		
		try {
			wisCommentList = new ArrayList<AdoptComment>();
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, iNo);
			
			rset = pstmt.executeQuery();
			
			while(rset.next()) {
				AdoptComment ac = new AdoptComment();
				
				ac.setIcNo(rset.getInt("ICNO"));
				ac.setiNo(iNo);
				ac.setIcContent(rset.getString("ICCONTENT"));
				ac.setIcWriter(rset.getString("ICWRITER"));
				ac.setIcdate(rset.getDate("ICDATE"));
				ac.setIcRefno(rset.getInt("ICREFNO"));
				ac.setIcLevel(rset.getInt("ICLEVEL"));
				
				wisCommentList.add(ac);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		return wisCommentList;
	}

	public int updateAdoptComment(Connection con, AdoptComment awc) {
		int result = 0;
		PreparedStatement pstmt = null;
		String sql = prop.getProperty("updateAdoptComment");
		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, awc.getIcContent());
			pstmt.setInt(2, awc.getiNo());
			pstmt.setInt(3, awc.getIcNo());
			
			result = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}
}
