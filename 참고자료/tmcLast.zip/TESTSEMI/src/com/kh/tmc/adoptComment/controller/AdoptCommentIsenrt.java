package com.kh.tmc.adoptComment.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.adoptComment.model.service.AdoptCommentService;
import com.kh.tmc.adoptComment.model.vo.AdoptComment;

/**
 * Servlet implementation class AdoptCommentIsenrt
 */
@WebServlet("/iAdoptCo.ado")
public class AdoptCommentIsenrt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdoptCommentIsenrt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String icWriter = request.getParameter("icWriter");
		int iNo = Integer.parseInt(request.getParameter("iNo"));
		int icRefno = Integer.parseInt(request.getParameter("icRefno"));
		int icLevel = Integer.parseInt(request.getParameter("icLevel"));
		String icContent = request.getParameter("icContent");
		
		AdoptComment ac = new AdoptComment(iNo,icContent,icWriter,icRefno,icLevel);
		
		
		
		int result = new AdoptCommentService().insertAdoptCommentInsert(ac);
		
		if(result > 0) {
			response.sendRedirect("soAdopt.ado?iNo="+iNo);
		}else {
			request.setAttribute("msg", "댓글 작성 실패 !");
			request.getRequestDispatcher("views/common/errorPage.jsp").forward(request, response);
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
