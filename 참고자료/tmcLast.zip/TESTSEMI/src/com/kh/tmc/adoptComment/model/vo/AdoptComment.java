package com.kh.tmc.adoptComment.model.vo;

import java.io.Serializable;
import java.sql.Date;

public class AdoptComment implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7640075348810392688L;
	private int icNo;
	private int iNo;
	private String icContent;
	private String icWriter;
	private Date icdate;
	private int icRefno;
	private int icLevel;
	
	public AdoptComment(int iNo, String icContent, String icWriter, int icRefno, int icLevel) {
		super();
		this.iNo = iNo;
		this.icContent = icContent;
		this.icWriter = icWriter;
		this.icRefno = icRefno;
		this.icLevel = icLevel;
	}

	public AdoptComment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getIcNo() {
		return icNo;
	}

	public void setIcNo(int icNo) {
		this.icNo = icNo;
	}

	public int getiNo() {
		return iNo;
	}

	public void setiNo(int iNo) {
		this.iNo = iNo;
	}

	public String getIcContent() {
		return icContent;
	}

	public void setIcContent(String icContent) {
		this.icContent = icContent;
	}

	public String getIcWriter() {
		return icWriter;
	}

	public void setIcWriter(String icWriter) {
		this.icWriter = icWriter;
	}

	public Date getIcdate() {
		return icdate;
	}

	public void setIcdate(Date icdate) {
		this.icdate = icdate;
	}

	public int getIcRefno() {
		return icRefno;
	}

	public void setIcRefno(int icRefno) {
		this.icRefno = icRefno;
	}

	public int getIcLevel() {
		return icLevel;
	}

	public void setIcLevel(int icLevel) {
		this.icLevel = icLevel;
	}

	public AdoptComment(int icNo, int iNo, String icContent, String icWriter, Date icdate, int icRefno, int icLevel) {
		super();
		this.icNo = icNo;
		this.iNo = iNo;
		this.icContent = icContent;
		this.icWriter = icWriter;
		this.icdate = icdate;
		this.icRefno = icRefno;
		this.icLevel = icLevel;
	}
	
	
	
	
	
}
