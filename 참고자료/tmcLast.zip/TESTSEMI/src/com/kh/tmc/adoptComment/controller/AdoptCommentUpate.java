package com.kh.tmc.adoptComment.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.tmc.adoptComment.model.service.AdoptCommentService;
import com.kh.tmc.adoptComment.model.vo.AdoptComment;

/**
 * Servlet implementation class AdoptCommentUpate
 */
@WebServlet("/uAdoptCo.ado")
public class AdoptCommentUpate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdoptCommentUpate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int icNo = Integer.parseInt(request.getParameter("icNo"));
		int iNo = Integer.parseInt(request.getParameter("iNo"));
		String icContent = request.getParameter("icContent");
		
		AdoptComment ac = new AdoptComment();
		ac.setIcNo(icNo);
		ac.setiNo(iNo);
		ac.setIcContent(icContent);
		
		AdoptCommentService awcs = new AdoptCommentService();
		
		int result = awcs.updateAdoptComment(ac);
		
		if(result>0) {
			response.sendRedirect("soAdoptW.ado?wiBno="+iNo);
		}else {
			request.setAttribute("msg", "댓글 수정 실패!!");
			request.getRequestDispatcher("views/common/errorPage.jsp").forward(request, response);;
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
