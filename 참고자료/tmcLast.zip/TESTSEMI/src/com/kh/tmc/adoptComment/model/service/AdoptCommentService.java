package com.kh.tmc.adoptComment.model.service;

import static com.kh.tmc.common.JDBCTemplate.close;
import static com.kh.tmc.common.JDBCTemplate.commit;
import static com.kh.tmc.common.JDBCTemplate.getConnection;
import static com.kh.tmc.common.JDBCTemplate.rollback;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.tmc.adoptComment.model.dao.AdoptCommentDao;
import com.kh.tmc.adoptComment.model.vo.AdoptComment;
import com.kh.tmc.adoptWantComment.model.vo.AdoptWantComment;

public class AdoptCommentService {

private AdoptCommentDao acDao = new AdoptCommentDao();
	
	public int deleteComment(AdoptComment ac) {
		Connection con = getConnection();
		
		int result = acDao.deleteComment(con,ac);
		
		if(result>0) commit(con);
		else rollback(con);
		
		return result;
	}

	public int insertAdoptCommentInsert(AdoptComment ac) {
		
		Connection con = getConnection();
		
		int result = acDao.insertAdoptCommentInsert(con,ac);
		
		if(result>0) commit(con);
		else rollback(con);
		
		close(con);
		
		return result;
		
	}

	public ArrayList<AdoptComment> selectAdoptCommentList(int iNo) {
		Connection con = getConnection();
		
		ArrayList<AdoptComment> isCommentList = acDao.selectAdoptCommentList(con, iNo);
		
		close(con);
		
		return isCommentList;
	}

	public int updateAdoptComment(AdoptComment ac) {
		Connection con = getConnection();
		
		int result = acDao.updateAdoptComment(con,ac);
		
		if(result>0) commit(con);
		else rollback(con);
		close(con);
		
		return result;
	}

}
